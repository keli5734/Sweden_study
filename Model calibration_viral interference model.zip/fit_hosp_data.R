library(tidyr)
library(deSolve)
library(dplyr)
 

clean_data <-  readRDS("clean_data_RSV_FLU_subset.rds")

# clean_data %>% 
#   ggplot() + 
#   geom_line(aes(x = epi_week_cdc, y= RSV, group = season)) + 
#   facet_wrap(~season)

# calibrate model with the first 10 years from the 1998/1999 season to 2008/2009 season 

data_fit_null_model <- clean_data %>% 
  #filter(date <= "2009-07-01") %>% 
  select(RSV, season, epi_week_cdc)


set.seed(1250)


source("fit_hosp_data_fn.R")
fitLL <- optim(par=c(-3, -1.8, -2, 2), #c(-1.6, .1, 2.197225, -0.22, -3, -1.8, -2, 2), 
               fn = fit_hosp_data_fn, # the distance function to optimise
               dat = data_fit_null_model, # the dataset we fit to
               # ("dat" argument is passed to the function specified in fn)
               control = list(fnscale= -1),  # negative log likelihood # here we minimize the negative log likelihood
               hessian = TRUE) 




parms <- c(parm_for_fit,
           xi1=10^(fitLL$par[1]),
           xi2=10^(fitLL$par[2]),
           xi3=10^(fitLL$par[3]),
           eta=exp(fitLL$par[4]))


saveRDS(parms, "calibrated_parms_viral_interference_model3.rds")
saveRDS(fitLL, "fitLL_model3.rds")