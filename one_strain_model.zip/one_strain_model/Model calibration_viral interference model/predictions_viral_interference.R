library(deSolve)
library(RColorBrewer)
library(reshape2)
library(readxl)
library(tidyverse)

setwd(dir = "/Users/ke/Desktop/OneDrive - Yale University/Postdoc/virus-virus interfernce/Sweden/sweden/")

source("revision/parameter_setting_viral_interference.R")
source("revision/RSV_transmission_model_interferen_climate.R")


results <- ode(y = yinit.vector, 
               time = my_times, 
               func = RSV_transmission_model_interference_climate, 
               parms = my_parmset_interference)



burnN <- t_burn_in

results.burned <- results[-c(1:burnN),]

pop.all <- rowSums(results.burned[,-1])



### calculate hospitalization
#proportion of first infections that are LRI (by age)
delta1=c(rep(.40,3),rep(.39,3),rep(.21,3),
         rep(.20,3),0.16,rep(.14,3),rep(0.05,N_ages-16))
#proportion of second infections that are LRI
delta2=.5*delta1
#proportion of third infections that are LRI
delta3=.7*delta2

###########################################
# Hospitalization probability
###########################################
#proportion of first infection that are hospitalized
hosp1=c(.18*rep(.40,3),0.08*rep(.39,3),
        0.07*rep(.21,3),0.06*rep(.20,3),0.06*0.16,
        0.05*rep(.14,3),0.02*rep(0.05,N_ages-16))
# = hosp prob given LRI * LRI prob given infection
#proportion of second infection that are hospitalized
hosp2=.4*hosp1
#proportion of subsequent infection that are hospitalized #(The last two probabilities come from the previous #fitting of the transmission dynamic model)
hosp3=c(rep(0,N_ages-2),0.00001,0.00004)


q <- 1
b <-  my_parmset_interference$baseline.txn.rate/(my_parmset_interference$dur.days1/7)
beta <- (b/100)/(sum(yinit.matrix)^(1-q))*my_parmset_interference$contact
Amp <-  my_parmset_interference$Amp
phi <-  my_parmset_interference$phi
t0 <-  nrow(results.burned)


I1 <- results.burned[,grep('I1', colnames(results.burned))]
I2 <- results.burned[,grep('I2', colnames(results.burned))]
I3 <- results.burned[,grep('I3', colnames(results.burned))]
I4 <- results.burned[,grep('I4', colnames(results.burned))]
S0 <- results.burned[,grep('S0', colnames(results.burned))]
S1 <- results.burned[,grep('S1', colnames(results.burned))]
S2 <- results.burned[,grep('S2', colnames(results.burned))]
S3 <- results.burned[,grep('S3', colnames(results.burned))]


lambda1=matrix(0,nrow=t0,ncol=N_ages)
for (t in 1:t0) {lambda1[t,]<-as.vector((1+Amp*cos(2*pi*(t-phi*52.1775)/52.1775))*
                                          ((I1[t,]+rho1*I2[t,]+rho2*I3[t,]+rho2*I4[t,])
                                           %*%beta)/sum(results.burned[t,]))}



H1=matrix(0,nrow=t0,ncol=N_ages)
for (i in 1:N_ages){
  H1[,i]=hosp1[i]*S0[,i]*lambda1[,i]+
    hosp2[i]*sigma1*S1[,i]*lambda1[,i]+
    hosp3[i]*sigma2*S2[,i]*lambda1[,i]+
    hosp3[i]*sigma3*S3[,i]*lambda1[,i]}

H_predicted <- rowSums(H1)
H_predicted <- H_predicted * my_parmset_interference$reporting_fraction


RSV_data <-  readRDS("data_process/clean_data_RSV_FLU.rds")

plot(RSV_data$date, RSV_data$RSV, type = "l", lwd = 2,  ylim = c(0,80))
lines(RSV_data$date,H_predicted, lwd = 2, col = "purple")
lines(RSV_data$date, null_model, lwd = 2, col = "grey")

# 
# plot(RSV_data$date, RSV_data$RSV, lwd = 2, col = "black", type = "l", ylim = c(0,80))
# lines(RSV_data$date, RSV_data$Influenza, lwd = 2, col = "red")



# lambda_mean <- rowMeans(lambda1) 
# 
# clean_data <-  readRDS("data_process/clean_data_RSV_FLU.rds")
# 
# bif.df_without <- data.frame(lambda = lambda_mean, 
#                      H_predicted = H_predicted / pop.all,
#                      season = rep(unique(clean_data$season), each = 52))  %>% 
#   mutate(pre_after_pandemic = ifelse(season %in% c("1998-1999", "1999-2000", "2000-2001", "2001-2002", "2002-2003", 
#                                                    "2003-2004", "2004-2005", "2005-2006","2006-2007", "2007-2008",
#                                                    "2008-2009"), "pre-pandemic", "after pandemic"))
# test = readRDS("baseline_H.rds") 
# plot(test, type = "l", col = "red")
# lines(H_predicted)

# 
# 
# clean_data <-  readRDS("data_process/clean_data_RSV_FLU.rds")
# 
# 
# data_fit_null_model <- clean_data %>%
#   #filter(date <= "2009-07-01") %>%
#   select(RSV, season, epi_week_cdc)
# 
# hospitalisation_data <- data_fit_null_model$RSV
# 
# #H_predicted2 <- readRDS("Fig3B.rds")
# 
# plot(clean_data$date, hospitalisation_data,type="l",xlab="Date",
#      ylab="Weekly RSV admissions", ylim = c(0,50), lwd = 2, main = "", col = "#74add1")
# lines(clean_data$date,H_predicted2, col = "black", lwd = 2)
# lines(clean_data$date, H_predicted, col = "red")
# legend("topleft", legend = c("RSV admission data", "Model Predictions"),
#        col = c("#74add1", "black"), lwd = 3)
# 
#  
# 
# H_predicted1 <- readRDS("Fig3A.rds")
# H_predicted2 <- readRDS("Fig3B.rds")
# 
# 
# 
# prediction_df <- data.frame(hosp = c(H_predicted1, H_predicted2, hospitalisation_data),
#                             group = rep(c(as.factor(1:(2+1))), each = length(hospitalisation_data)),
#                             type = rep(c(as.factor(1:3)), c(length(hospitalisation_data),
#                                                             length(hospitalisation_data),
#                                                             length(hospitalisation_data)*(2-1))),
#                             date = rep(clean_data$date, (2+1)))
# 
# 
# 
# # prediction_df <-  readRDS("model_predictions_viral_interference.rds")
# # 
# prediction_df1 <- prediction_df %>% filter(type == "1")
# prediction_df2 <- prediction_df %>% filter(type == "2")
# prediction_df3 <- prediction_df %>% filter(type == "3") %>%
#   mutate(threshold = as.Date("2009-06-29"))
# 
# 
# 
# 
# ggplot() +
#   geom_line(data = prediction_df3, aes(x = date, y = hosp, color = "RSV admission data"), linewidth = 1.3) +
#   #geom_line(data = prediction_df1, aes(x = date, y = hosp, color = "Model prediction"),  linewidth = 1) +
#   geom_line(data = prediction_df2, aes(x = date, y = hosp, color = "Model prediction"), linewidth = 1) +
#    
#   geom_vline(aes(xintercept = as.Date("2009-07-01")), linetype = "dashed", color = "#f1b6da", linewidth  = 1.2)+
#   theme_minimal()  +
#   labs(y = "Weekly RSV admission",
#        x = "Date") +
#   guides(alpha = "none") +
#   scale_color_manual(name = NULL,
#                      values = c(
#                        "RSV admission data" = "#74add1",
#                        "Model prediction" = "black",
#                        "Model prediction" = "black")) +
#   scale_y_continuous(limits = c(0,50))  +
#   theme(panel.border = element_blank(), axis.line = element_line(colour = "black")) +
#   theme(
#     axis.text.x = element_text(face="bold"),
#     axis.text.y = element_text(face="bold"),
#     axis.title.x = element_text(face="bold"),
#     axis.title.y = element_text(face="bold"),
#     plot.title = element_text(face="bold", hjust = 0.5),
#     #axis.line = element_blank(),
#     panel.grid.major = element_blank(),
#     panel.grid.minor = element_blank(),
#     legend.position = "top") +
#   theme(axis.text.x = element_text(color="black",
#                                    size = 20, angle=0),
#         axis.text.y = element_text(color="black",
#                                    size= 20, angle=0),
#         text = element_text(size = 20)) 



