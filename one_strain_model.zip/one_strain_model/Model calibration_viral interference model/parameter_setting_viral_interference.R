
# Define age group and Birth rate 
N_ages <- 21

  

#Create a vector with the given values

b <- c(15.931, 15.741, 15.551, 15.361, 15.171, 14.981, 14.791, 14.601,
       14.411, 14.498, 14.585, 14.672, 14.759, 14.846, 14.832, 14.818,
       14.805, 14.791, 14.777, 14.524, 14.271, 14.018, 13.765, 13.512,
       13.149, 12.786, 12.423, 12.06, 11.697, 11.622, 11.547, 11.471,
       11.396, 11.321, 11.649, 11.977, 12.306, 12.634, 12.962,
       13.078, 13.194, 13.31, 13.426, 13.542, 12.907, 12.272, 11.636, 11.536)/1000

years_burn_ins <- seq(from = 1950, to = 1997, by = 1)
dates <- as.Date(paste0(years_burn_ins, "-07-01"))
date2_interpolate <- seq(as.Date("1950-07-01"), as.Date("1997-07-01"), by = "7 days")

B_part2 <- approx(x = dates,
                  y = b,
                  xout = date2_interpolate)$y
B_part2 <- B_part2[1:2444]

  

b <- c(0.01142333,
       0.01142333, 0.01151715, 0.01135549, 0.01180138,
       0.01229689, 0.01298240, 0.01344792, 0.01399251,
       0.01384226, 0.01430449, 0.01429987, 0.01434508,
       0.01451860, 0.01484883, 0.01416039, 0.01406637,
       0.01412209, 0.01386747, 0.01361336, 0.01339975)


 
years <- seq(from  = 1996, to = 2016, by = 1)
dates <- as.Date(paste0(years, "-07-01"))
date3_interpolate <- seq(as.Date("1996-07-01"), as.Date("2017-07-01"), by = "7 days")

B_part3 <- approx(x = dates,
                  y = b,
                  xout = date3_interpolate)$y

B_part3 <- B_part3[1:936]
B <- c(B_part2, B_part3)
B_combined <- matrix(data = 0, nrow = length(B), ncol = N_ages)
B_combined[,1] <- B

######

contact_mat <- readRDS("contact_mat_POLYMOND.rds") # POLYMOD
colnames(contact_mat) <- NULL 
#contact_mat <- readRDS("contactSweden.rds")

WidthAgeClassMonth <-  c(rep(1,times=12), rep(12,times=4), 60, 120, 240, 240, 240)  #Aging rate=1/width age class (months) Vector of long N_age

### population in 1998 ###
Population_age_group_1 <- readRDS("population_0-1 yr.rds")[1]  
Population_age_group_2 <- readRDS("population_1-2 yr.rds")[1]
Population_age_group_3 <- readRDS("population_2-3 yr.rds")[1]
Population_age_group_4 <- readRDS("population_3-4 yr.rds")[1]
Population_age_group_5 <- readRDS("population_4-5 yr.rds")[1]
Population_age_group_6 <- readRDS("population_5-9 yr.rds")[1]
Population_age_group_7 <- readRDS("population_10-19 yr.rds")[1]
Population_age_group_8 <- readRDS("population_20-39 yr.rds")[1]
Population_age_group_9 <- readRDS("population_40-59 yr.rds")[1]
Population_age_group_10 <- readRDS("population_60 above.rds")[1]


Population_age_under_1 <- round(Population_age_group_1 / 12)


### estimated net migrations rates ###
migration_rates <-  readRDS("migration_rate.rds") # -0.0002227

migration_rates_gp <- c(rep(migration_rates["mu1"], 14),
                        rep(migration_rates["mu2"], 4), 
                        migration_rates["mu3"], 
                        migration_rates["mu4"], 
                        migration_rates["mu5"])

migration_rates_gp <- as.numeric(migration_rates_gp)


### population in 1930 ###
t_burn_in <-  length(c(B_part2))  

birth.rate <- log(mean(c(B_part2))+1)/52.18

#migration_rates <- log(migration_rates+1)/52.18

N0_grp1 <- Population_age_under_1 * exp(-(birth.rate+migration_rates["mu1"]) * t_burn_in)  # under 1
N0_grp2 <- Population_age_group_2 * exp(-(birth.rate+migration_rates["mu1"]) * t_burn_in)  # 1-2
N0_grp3 <- Population_age_group_3 * exp(-(birth.rate+migration_rates["mu1"]) * t_burn_in)  # 2-3  
N0_grp4 <- Population_age_group_4 * exp(-(birth.rate+migration_rates["mu1"]) * t_burn_in)  # 3-4  
N0_grp5 <- Population_age_group_5 * exp(-(birth.rate+migration_rates["mu1"]) * t_burn_in)  # 4-5
N0_grp6 <- Population_age_group_6 * exp(-(birth.rate+migration_rates["mu2"]) * t_burn_in)  # 5-9
N0_grp7 <- Population_age_group_7 * exp(-(birth.rate+migration_rates["mu2"]) * t_burn_in)  # 10-19
N0_grp8 <- Population_age_group_8 * exp(-(birth.rate+migration_rates["mu3"]) * t_burn_in)  # 20-39
N0_grp9 <- Population_age_group_9 * exp(-(birth.rate+migration_rates["mu4"]) * t_burn_in)  # 40-59
N0_grp10 <- Population_age_group_10 * exp(-(birth.rate+migration_rates["mu5"]) * t_burn_in) # above 60

Pop1 <- c(N1 = (N0_grp1),
          N2 = (N0_grp1), 
          N3 = (N0_grp1),
          N4 = (N0_grp1),
          N5 = (N0_grp1),
          N6 = (N0_grp1),
          N7 = (N0_grp1),
          N8 = (N0_grp1), 
          N9 = (N0_grp1),
          N10 = (N0_grp1),
          N11 = (N0_grp1),
          N12 = (N0_grp1),
          N13 = (N0_grp2),
          N14 = (N0_grp3), 
          N15 = (N0_grp4),
          N16 = (N0_grp5),
          N17 = (N0_grp6),
          N18 = (N0_grp7),
          N19 = (N0_grp8),
          N20 = (N0_grp9),
          N21 = (N0_grp10))

N_ages <- length(Pop1) 
agenames <- paste0('Agegrp', 1:N_ages) 
names(Pop1) <- agenames 

## Initialize the compartments (States) 
StateNames <- c("M", 
                "S0", "I1", "S1", "I2", "S2", "I3", "S3", "I4",
                 "R1", "R2", "R3","R4", "R5")


States <- array(NA, dim=c(N_ages, length(StateNames) )) #  N age groups x N parameters 
dimnames(States)[[1]] <- agenames
dimnames(States)[[2]] <- StateNames

yinit.matrix <- array(NA, dim=c(N_ages, length(StateNames) ))

dimnames(yinit.matrix)[[1]] <- agenames
dimnames(yinit.matrix)[[2]] <- StateNames

yinit.matrix[,c("S1", "I2", "S2", "I3", "S3", "I4", 
                "R1", "R2", "R3", "R4", "R5")]  <-  0 # setting initial conditions

yinit.matrix[,'M']  <-  c(Pop1[1:6], rep(0,N_ages-6))
yinit.matrix[,'S0'] <-  c(rep(0,6),Pop1[7:N_ages]-rep(1)) 
yinit.matrix[,c('I1')]  <-  c(rep(0,6), rep(1,N_ages-6)) 


yinit.vector <- as.vector(yinit.matrix) #Vectorize the ynit matrix

# Create array that has the labels by age, State and use this to name the yinit.vector
name.array <- array(NA, dim=dim(yinit.matrix)) # dim = 21 x 25 (21 age groups x 25 model compartments) 
for(i in 1:dim(name.array)[1]){ # for 1:21 age groups 
  for(j in 1:dim(name.array)[2]){ # for 1:25 model compartnments (stages)
    name.array[i,j] <- paste(dimnames(yinit.matrix)[[1]][i],dimnames(yinit.matrix)[[2]][j])
  }
}

name.vector <- as.vector(name.array)
names(yinit.vector) <- name.vector



start_time <- 1 # start date (in week)
tmax <- nrow(B_combined) # end_time (in week)
my_times <- seq(start_time, tmax, by = 1) # gives a sequence from start to end in increments of 1



#########################################
#Relative infectiousness for 2nd and subsequent infections
rho1 <- 0.75
rho2 <- 0.51

#########################################
# duration of infectiousness (months)
#Duration in days
dur.days1 <- 10 #days
dur.days2 <- 7 #days
dur.days3 <- 5 #days


###########################################
# 1/duration of maternal immunity (DAYS)
DurationMatImmunityDays <- 112


#############################################
PerCapitaBirthsYear <- B_combined 


#Relative risk of infection following 1st, 2nd, 3rd+ infections
sigma1 <- 0.76
sigma2 <- 0.6
sigma3 <- 0.4



# baseline.txn.rate <- 9
# phi <-  3.298 #0
# Amp <-  0.2 #0.3
q <-  1



influenza1 <- readRDS("influenza1.rds")
influenza2 <- readRDS("influenza2.rds")
influenza3 <- readRDS("influenza3.rds")
 
calibrated_parms <-	readRDS("calibrated_parms_partial_dataset.rds")


parm_for_fit <- list(PerCapitaBirthsYear=PerCapitaBirthsYear,
                                WidthAgeClassMonth = WidthAgeClassMonth,
                                DurationMatImmunityDays = DurationMatImmunityDays,
                                mu = migration_rates_gp,
                                rho1=rho1,
                                rho2=rho2,
                                dur.days1=dur.days1,
                                dur.days2=dur.days2,
                                dur.days3=dur.days3,
                                yinit.matrix=yinit.matrix,
                                q=q,
                                baseline.txn.rate = calibrated_parms$baseline.txn.rate,
                                Amp = calibrated_parms$Amp ,
                                phi = calibrated_parms$phi,
                                reporting_fraction = calibrated_parms$reporting_fraction,
                                contact=contact_mat,
                                sigma1=sigma1,
                                sigma2=sigma2,
                                sigma3= sigma3,
                                time.step = 'week',
                                influenza1 = influenza1,
                                influenza2 = influenza2, 
                                influenza3 = influenza3)

 
 

