#!/bin/bash
#SBATCH -J model_calibration
#SBATCH --mem=10G
#SBATCH --time=1-00:00:00
#SBATCH --mail-type=ALL
#SBATCH --mail-user=ke.li.kl662@yale.edu
#SBATCH -o calibration.out

Rscript fit_hosp_data.R
