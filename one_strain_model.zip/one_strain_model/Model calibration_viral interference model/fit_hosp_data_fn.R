source("parameter_setting_viral_interference.R")
source("RSV_transmission_model_interferen_climate.R")


fit_hosp_data_fn <- function(parameters, dat) {
  
  

  
  v1 <- parameters[1] # xi1
  v2 <- parameters[2] # xi2
  v3 <- parameters[3] # xi3 
  waning <- parameters[4] # eta 
 
  
 
  

  
  xi1 <- 10^(v1)
  xi2 <- 10^(v2)
  xi3 <- 10^(v3)
  eta <- exp(waning)
   
  
  
  
  
  xi1 <<- xi1
  xi2 <<- xi2
  xi3 <<- xi3
  eta <<- eta 
   
  
  results <- ode(y = yinit.vector, 
                 t = my_times,  
                 func = RSV_transmission_model_interference_climate, 
                 parms = c(parm_for_fit,
                           xi1 = xi1,
                           xi2 = xi2,
                           xi3 = xi3,
                           eta = eta),
                 atol = 1e-6, 
                 rtol = 1e-6,
                 maxsteps = 10000)
                          
  
  
  burnN <- t_burn_in
  results.burned <- results[-c(1:burnN),]
  
  
  
  ### calculate hospitalization 
  #proportion of first infections that are LRI (by age)
  delta1=c(rep(.40,3),rep(.39,3),rep(.21,3),
           rep(.20,3),0.16,rep(.14,3),rep(0.05,N_ages-16))
  #proportion of second infections that are LRI
  delta2=.5*delta1
  #proportion of third infections that are LRI 
  delta3=.7*delta2 
  
  ###########################################
  # Hospitalization probability
  ###########################################
  #proportion of first infection that are hospitalized
  hosp1=c(.18*rep(.40,3),0.08*rep(.39,3),
          0.07*rep(.21,3),0.06*rep(.20,3),0.06*0.16,
          0.05*rep(.14,3),0.02*rep(0.05,N_ages-16))
  # = hosp prob given LRI * LRI prob given infection
  #proportion of second infection that are hospitalized
  hosp2=.4*hosp1
  #proportion of subsequent infection that are hospitalized #(The last two probabilities come from the previous #fitting of the transmission dynamic model) 
  hosp3=c(rep(0,N_ages-2),0.00001,0.00004)
  
  
  q <- 1 
  beta0 <-  parm_for_fit$baseline.txn.rate/(parm_for_fit$dur.days1/7)
  beta <- (beta0/100)/(sum(yinit.matrix)^(1-q))*parm_for_fit$contact
  Amp <-  parm_for_fit$Amp
  phi <-  parm_for_fit$phi
  
 
   
  t0 = nrow(results.burned)
 
  
  I1 <- results.burned[,grep('I1', colnames(results.burned))] 
  I2 <- results.burned[,grep('I2', colnames(results.burned))]
  I3 <- results.burned[,grep('I3', colnames(results.burned))]
  I4 <- results.burned[,grep('I4', colnames(results.burned))]
  S0 <- results.burned[,grep('S0', colnames(results.burned))]
  S1 <- results.burned[,grep('S1', colnames(results.burned))]
  S2 <- results.burned[,grep('S2', colnames(results.burned))]
  S3 <- results.burned[,grep('S3', colnames(results.burned))]
  
  
  lambda1=matrix(0,nrow=t0,ncol=N_ages)
  for (t in 1:t0) {lambda1[t,]<-as.vector((1+Amp*cos(2*pi*(t-phi*52.1775)/52.1775))*
                                            ((I1[t,]+rho1*I2[t,]+rho2*I3[t,]+rho2*I4[t,])
                                             %*%beta)/sum(results.burned[t,]))}
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*S0[,i]*lambda1[,i]+
      hosp2[i]*sigma1*S1[,i]*lambda1[,i]+
      hosp3[i]*sigma2*S2[,i]*lambda1[,i]+
      hosp3[i]*sigma3*S3[,i]*lambda1[,i]}
  
  H <- rowSums(H1)
  H_true <- H#[1:572] # only fit to the first 11 seasons (1997-2018)
  
  
  data_fit <- dat$RSV#[1:572] # only fit to the first 11 seasons (1997-2018)
  
  
  LLall<-sum(dpois(x = data_fit,
                   #lambda = H_true * parm_for_fit$reporting_fraction,
                   lambda = H_true * parm_for_fit$reporting_fraction,
                   log = T))
  
  
  # trend is defined as the two-year moving-average of the simulated data 
  # trend <- infected.all.df %>% 
  #   mutate(moving_average = rollmean(data, 104, align = "right", fill = NA)) %>% 
  #   filter(!is.na(moving_average))
  # 
  # 
  # true_value <- infected.all.df$data  
  # data_fit <- dat$total_number_positive
  # 
  # 
  # LLall <- sum(dpois(x = data_fit, 
  #                    lambda = true_value * reporting_fraction * trend, 
  #                    log = TRUE)
  # ) 
  
  
  #prior
  #durprior <- dgamma(x=durx,22,5,log=T)
  #baseline_prior <- dunif(x = baseline.txn.rate, min = 2, max = 3)
  #Amp_prior <- dunif(x = Amp, min = - 2, max = .1)
  #durprior <- dgamma(x=DurationMatImmunityDays,22,5,log=T)
  # give a prior for the duration of maternal immunity  
  
  #total Loglikelihood (because of log, we sum up)
  
  LL <- LLall  #+ baseline_prior + Amp_prior + durprior
  
  return(LL)
}


