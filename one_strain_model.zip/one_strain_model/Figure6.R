
library(tidyverse)

 
# Load all necessary objects in one go
clean_data <- readRDS("clean_data_RSV_FLU_subset.rds")
data_list <- readRDS("phase_plot_data_uncertainty.rds") # loading 95%CrI data
results.burned <- data_list$results.burned
results.burned2 <- data_list$results.burned2
pop.all <- data_list$pop.all
pop.all2 <- data_list$pop.all2
clean_data <- data_list$clean_data


 
 
infected.cols <- results.burned[,
                                c(grep('I1', colnames(results.burned)))]
 

infected.cols2 <- results.burned2[,
                                  c(grep('I1', colnames(results.burned2)))]
 



susp.cols <- results.burned[,
                            c(grep('S0', colnames(results.burned)))]
 

susp.cols2 <- results.burned2[,
                              c(grep('S0', colnames(results.burned2)))]
 




refractory.cols <- results.burned[,
                                  c(grep('R1', colnames(results.burned)))]
 

refractory.cols2 <- results.burned2[,
                                    c(grep('R1', colnames(results.burned2)))]
 




# Sum up the infected individuals at each time point
infected.all <- apply(infected.cols,1,sum)
susp.cols <- apply(susp.cols,1,sum)
refractory.cols <- apply(refractory.cols,1, sum)
x = susp.cols/pop.all*100
y = infected.all/pop.all*100
z = refractory.cols/pop.all*100


# Sum up the infected individuals at each time point
infected.all2 <- apply(infected.cols2,1,sum)
susp.cols2 <- apply(susp.cols2,1,sum)
refractory.cols2 <- apply(refractory.cols2,1, sum)
x2 = susp.cols2/pop.all2*100
y2 = infected.all2/pop.all2*100
z2 = refractory.cols2/pop.all2*100



 

phase_plot <- data.frame(S = x,
                         I = y,
                         Z = z,
                         S2 = x2,
                         I2 = y2,
                         Z2 = z2,
                         season = clean_data$season,
                         date = clean_data$date)

 
 

                         
df <- phase_plot %>%
  mutate(date = as.Date(date))  # Convert date to Date class


# Reshape to long format for plotting values
lower_df <- df %>%
  dplyr:: select(date, S, Z, I) %>%
  pivot_longer(cols = c(S, Z, I), names_to = "type", values_to = "lower")

# Reshape to long format for upper bounds (95% CI)
upper_df <- df %>%
  dplyr::select(date, S2, Z2, I2) %>%
  rename(S = S2, I = I2, Z= Z2) %>%
  pivot_longer(cols = c(S, Z, I), names_to = "type", values_to = "upper")

# Join upper bounds to main data
plot_df <- lower_df %>%
  left_join(upper_df, by = c("date", "type")) %>% 
  mutate(type = ifelse(type == "S", "Susceptible population", 
                       ifelse(type == "Z","Temporarily-immune population", "Infected population"))) %>% 
  mutate(group = ifelse(type == "Susceptible population", "S1(i)", 
                        ifelse(type == "Temporarily-immune population", "R1", "I1(i)")))  %>% 
  mutate(type = factor(type, levels = c("Susceptible population", "Temporarily-immune population","Infected population") )) 
  

 

 Figure6ss <- 
  ggplot() + 
  geom_ribbon(data = plot_df, aes(x = date, ymin = lower, ymax = upper, group = group),
              fill = "#fc4e2a", alpha = 0.3) +
  facet_wrap(~type, nrow = 3, scales = "free_y") + 
  ylab("% of total population") + xlab("Date") +
  theme_minimal()+
  theme(panel.border = element_blank(), axis.line = element_line(colour = "black")) +
  theme(
    axis.text.x = element_text(face="bold"),
    axis.text.y = element_text(face="bold"),
    axis.title.x = element_text(face="bold"),
    axis.title.y = element_text(face="bold"),
    plot.title = element_text(face="bold", hjust = 0.5),
    panel.grid.major = element_blank(),
    strip.text = element_text(size = 20, face = "bold"),
    #panel.grid.minor = element_blank(),
    legend.position = "NA") + 
  theme(axis.text.x = element_text(color="black",
                                   size = 20, angle=0),
        axis.text.y = element_text(color="black",
                                   size= 20, angle=0),
        text = element_text(size = 20))  


 Figure6ss
 

 results <- readRDS("viral_interference_basemodel.rds")
 results2 <- readRDS("viral_interference_best_case.rds")


 burnN <- 2444

 results.burned <- results[-c(1:burnN),]
 results.burned2 <- results2[-c(1:burnN),]

 pop.all <- rowSums(results.burned[,-1])
 pop.all2 <- rowSums(results.burned2[,-1])

 infected.cols <- results.burned[,
                                 c(grep('I1', colnames(results.burned)))]


 infected.cols2 <- results.burned2[,
                                   c(grep('I1', colnames(results.burned2)))]




 susp.cols <- results.burned[,
                             c(grep('S0', colnames(results.burned)))]


 susp.cols2 <- results.burned2[,
                               c(grep('S0', colnames(results.burned2)))]





 refractory.cols <- results.burned[,
                                   c(grep('R1', colnames(results.burned)))]


 refractory.cols2 <- results.burned2[,
                                     c(grep('R1', colnames(results.burned2)))]





 # Sum up the infected individuals at each time point
 infected.all <- apply(infected.cols,1,sum)
 susp.cols <- apply(susp.cols,1,sum)
 refractory.cols <- apply(refractory.cols,1, sum)
 x = susp.cols/pop.all
 y = infected.all/pop.all
 z = refractory.cols


 # Sum up the infected individuals at each time point
 infected.all2 <- apply(infected.cols2,1,sum)
 susp.cols2 <- apply(susp.cols2,1,sum)
 refractory.cols2 <- apply(refractory.cols2,1, sum)
 x2 = susp.cols2/pop.all2
 y2 = infected.all2/pop.all2
 z2 = refractory.cols2/pop.all2


 clean_data <-  readRDS("clean_data_RSV_FLU.rds")
 clean_data <- clean_data %>%
   filter(season != "2016-2017") %>%
   filter(season != "2017-2018")

 phase_plot <- data.frame(S = x,
                          S2 = x2,
                          Z = z2,
                          I = y,
                          I2 = y2,
                          season = clean_data$season,
                          date = clean_data$date,
                          rsv = clean_data$RSV)




 phase_plot2 <- data.frame(cases = c(x,x2,z2,y,y2,clean_data$RSV/13000) * 100, # /13000 * 100 is to scale the figure
                           season = rep(clean_data$season),
                           date = rep(clean_data$date),
                           type = rep(c("Susceptible population", "Temporarily-immune population" ,"Infected population"), c(936*2, 936, 936*3)),
                           group = rep(c("S1","S1(i)", "R1", "I1", "I1(i)", "Data"), each = 936)) %>%
 mutate(type = factor(type, levels = c("Susceptible population", "Temporarily-immune population","Infected population") ))


 color_blocks <- data.frame(
   xmin = as.Date(c("1998-07-06", "2009-06-29", "2010-06-28")),
   xmax = as.Date(c("2009-06-29", "2010-06-28", "2016-06-27")),
   fill = c("#91bfdb", "#af8dc3", "#fc8d59")
 )



 Figure6 = Figure6ss +
   geom_path(data = phase_plot2, aes(x = date, y = cases, group = group, color = group), linewidth = 1.2) +
   geom_rect(data = color_blocks, aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = fill), alpha = 0.05) +
   scale_fill_lancet()+
   facet_wrap(~type, nrow = 3, scales = "free_y") +
   scale_color_manual(name = NULL,
                      values = c(
                        "S1" = "black",
                        "S1(i)" = "#d94801",
                        "R1" = "#6baed6",
                        "I1" = "black",
                        "I1(i)" = "#d94801",
                        "Data" = "cornflowerblue")) +
   ylab("% of total population") + xlab("Date") +
   theme_minimal()+
   theme(panel.border = element_blank(), axis.line = element_line(colour = "black")) +
   theme(
     axis.text.x = element_text(face="bold"),
     axis.text.y = element_text(face="bold"),
     axis.title.x = element_text(face="bold"),
     axis.title.y = element_text(face="bold"),
     plot.title = element_text(face="bold", hjust = 0.5),
     panel.grid.major = element_blank(),
     strip.text = element_text(size = 20, face = "bold"),
     #panel.grid.minor = element_blank(),
     legend.position = "NA") +
   theme(axis.text.x = element_text(color="black",
                                    size = 20, angle=0),
         axis.text.y = element_text(color="black",
                                    size= 20, angle=0),
         text = element_text(size = 20))

 Figure6
