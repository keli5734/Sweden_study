library(readxl)
library(ggplot2)
library(tidyverse)
library(viridis)  
library(zoo)
library(adephylo)
library(cowplot)
library(gridExtra)
library(lubridate)
library(lattice)
library(grid)
library(ggpubr)
library(ape)
library(latex2exp)
library(lhs)
library(deSolve)
library(dplyr)
library(MASS)

 
 
set.seed(12345)

N_sample_size <- 100000 
N_varied_parameters <- 4

uniform_LHS <- randomLHS(N_sample_size, N_varied_parameters)
transformed_LHS <- matrix(NA, nrow = N_sample_size, ncol = N_varied_parameters)



transformed_LHS[,1] <- qunif(uniform_LHS[,1], min = -3, max = -1)  # xi1 
transformed_LHS[,2] <- qunif(uniform_LHS[,2], min = -2, max = 0)  # xi2 
transformed_LHS[,3] <- qunif(uniform_LHS[,3], min = -3, max = -1)  # xi3 
transformed_LHS[,4] <- qunif(uniform_LHS[,4], min = 1, max = 10)  # eta 



xi1 <- 10.^transformed_LHS[,1]
xi2 <- 10.^transformed_LHS[,2]
xi3 <- 10.^transformed_LHS[,3]
eta <- transformed_LHS[,4]
 

predicted_traj1 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run1.rds"))
predicted_traj2 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run2.rds"))
predicted_traj3 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run3.rds"))
predicted_traj4 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run4.rds"))
predicted_traj5 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run5.rds"))
predicted_traj6 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run6.rds"))
predicted_traj7 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run7.rds"))
predicted_traj8 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run8.rds"))
predicted_traj9 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run9.rds"))
predicted_traj10 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run10.rds"))

predicted_traj11 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run11.rds"))
predicted_traj12 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run12.rds"))
predicted_traj13 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run13.rds"))
predicted_traj14 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run14.rds"))
predicted_traj15 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run15.rds"))
predicted_traj16 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run16.rds"))
predicted_traj17 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run17.rds"))
predicted_traj18 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run18.rds"))
predicted_traj19 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run19.rds"))
predicted_traj20 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run20.rds"))

predicted_traj21 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run21.rds"))
predicted_traj22 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run22.rds"))
predicted_traj23 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run23.rds"))
predicted_traj24 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run24.rds"))
predicted_traj25 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run25.rds"))
predicted_traj26 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run26.rds"))
predicted_traj27 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run27.rds"))
predicted_traj28 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run28.rds"))
predicted_traj29 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run29.rds"))
predicted_traj30 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run30.rds"))

predicted_traj31 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run31.rds"))
predicted_traj32 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run32.rds"))
predicted_traj33 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run33.rds"))
predicted_traj34 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run34.rds"))
predicted_traj35 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run35.rds"))
predicted_traj36 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run36.rds"))
predicted_traj37 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run37.rds"))
predicted_traj38 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run38.rds"))
predicted_traj39 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run39.rds"))
predicted_traj40 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run40.rds"))

predicted_traj41 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run41.rds"))
predicted_traj42 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run42.rds"))
predicted_traj43 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run43.rds"))
predicted_traj44 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run44.rds"))
predicted_traj45 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run45.rds"))
predicted_traj46 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run46.rds"))
predicted_traj47 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run47.rds"))
predicted_traj48 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run48.rds"))
predicted_traj49 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run49.rds"))
predicted_traj50 <- readRDS(paste0("revision/results_test1/saved_rsv_dynamics_run50.rds"))


predicted_traj <- c(predicted_traj1,predicted_traj2, predicted_traj3,
                    predicted_traj4,predicted_traj5, predicted_traj6,
                    predicted_traj7,predicted_traj8, predicted_traj9, 
                    predicted_traj10,
                    predicted_traj11,predicted_traj12, predicted_traj13,
                    predicted_traj14,predicted_traj15, predicted_traj16,
                    predicted_traj17,predicted_traj18, predicted_traj19, 
                    predicted_traj20,
                    predicted_traj21,predicted_traj22, predicted_traj23,
                    predicted_traj24,predicted_traj25, predicted_traj26,
                    predicted_traj27,predicted_traj28, predicted_traj29, 
                    predicted_traj30,
                    predicted_traj31,predicted_traj32, predicted_traj33,
                    predicted_traj34,predicted_traj35, predicted_traj36,
                    predicted_traj37,predicted_traj38, predicted_traj39, 
                    predicted_traj40,
                    predicted_traj41,predicted_traj42, predicted_traj43,
                    predicted_traj44,predicted_traj45, predicted_traj46,
                    predicted_traj47,predicted_traj48, predicted_traj49, 
                    predicted_traj50)




predicted_traj <- Filter(function(x) !is.null(x) && length(x) > 0, predicted_traj)


rsv_data <-  readRDS("data_process/clean_data_RSV_FLU_subset.rds")

 
N_sample_size <- N_sample_size
goodness_of_fit_rsv <- c()
for (i in 1:N_sample_size) {
  
  prediction <- predicted_traj[[i]]
  goodness_of_fit_rsv[i] <- sum(dpois(x = rsv_data$RSV, 
                                      lambda = prediction,
                                      log = TRUE))
  
}


    

log_weights <- goodness_of_fit_rsv - max(goodness_of_fit_rsv)  # Normalize weights
weights <- exp(log_weights)
norm_weights <- weights / sum(weights)  # Normalize weights to sum to 1
 

 

n_resamples <- N_sample_size # keep 1-10 ratio

# Re-sample from the proposal distribution using the calculated weights for log10(xi)
resampled_indices_log10_theta1 <- sample(seq_along(xi2), size = n_resamples, replace = TRUE, prob = norm_weights)
posterior_samples_log10_theta1 <- xi2[resampled_indices_log10_theta1]
resampled_parameter_theta1 <- data.frame(x =  posterior_samples_log10_theta1)


posterior_samples_theta2 <- eta[resampled_indices_log10_theta1]
resampled_parameter_theta2 <- data.frame(x = posterior_samples_theta2)

posterior_samples_theta3 <- xi1[resampled_indices_log10_theta1]
resampled_parameter_theta3 <- data.frame(x = posterior_samples_theta3)

posterior_samples_theta4 <- xi3[resampled_indices_log10_theta1]
resampled_parameter_theta4 <- data.frame(x = posterior_samples_theta4)

#saveRDS(resampled_parameter_theta1, "sampled.rds")
 