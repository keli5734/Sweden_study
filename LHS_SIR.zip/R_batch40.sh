#!/bin/bash
#SBATCH -J fit40
#SBATCH --mem=5G
#SBATCH --partition week
#SBATCH --time=5-00:00:00
#SBATCH --mail-type=ALL
#SBATCH --mail-user=ke.li.kl662@yale.edu
#SBATCH -o fit40.out

Rscript LHS_viral_interference_parameter_run40.R
