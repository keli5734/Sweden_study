source("LHS_sampling.R")



saved_rsv_dynamics <- list()
 

source("parameter_setting_viral_interference.R")


N_run <- 49

for( nn in ((N_run-1)*len_each_run+1):(N_run*len_each_run) ){
  
  
 parm_added <- list(
                     xi1 = lhs.sample.mt[nn,1],
                     xi2 = lhs.sample.mt[nn,2],
                     xi3 = lhs.sample.mt[nn,3],
                     eta = lhs.sample.mt[nn,4]
                    )  
  
  
  
  
  
  my_parmset <- c(parm_for_fit, 
                  parm_added)
  
  source("forward_simulation_LHS.R")
    print(paste0("iteration ", nn, " has been done!"))

  saved_rsv_dynamics[[nn]] <-  H_predicted
  
}


saveRDS(saved_rsv_dynamics, paste0("results/saved_rsv_dynamics_run", N_run, ".rds"))





