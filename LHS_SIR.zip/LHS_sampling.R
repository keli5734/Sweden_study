if(!require(lhs)) install.packages("lhs", repos = "https://cran.rstudio.com/")
library(lhs)
library(deSolve)
library(dplyr)

set.seed(12345)
N_sample_size <- 100000
N_varied_parameters <- 7

uniform_LHS <- randomLHS(N_sample_size, N_varied_parameters)
transformed_LHS <- matrix(NA, nrow = N_sample_size, ncol = N_varied_parameters)



transformed_LHS[,1] <- qunif(uniform_LHS[,1], min = -3, max = -1)  # xi1 
transformed_LHS[,2] <- qunif(uniform_LHS[,2], min = -2, max = -0)  # xi2 
transformed_LHS[,3] <- qunif(uniform_LHS[,3], min = -3, max = -1)  # xi3 
transformed_LHS[,4] <- qunif(uniform_LHS[,4], min = 1, max = 10)  # eta 
transformed_LHS[,5] <- qnorm(uniform_LHS[,5], mean = 8.51, sd = .5)  # eta 
transformed_LHS[,6] <- qnorm(uniform_LHS[,6], mean = 0.27, sd = .1)  # eta 
transformed_LHS[,7] <- qnorm(uniform_LHS[,7], mean = 3.24, max = .5)  # eta 

 
xi1 <- 10.^transformed_LHS[,1]
xi2 <- 10.^transformed_LHS[,2]
xi3 <- 10.^transformed_LHS[,3]
eta <- transformed_LHS[,4]
beta <- transformed_LHS[,5]
amp <- transformed_LHS[,6]
phi <- transformed_LHS[,7]

lhs.sample.mt <- matrix(NA, nrow = N_sample_size, ncol = N_varied_parameters)
lhs.sample.mt[,1] <- xi1
lhs.sample.mt[,2] <- xi2
lhs.sample.mt[,3] <- xi3
lhs.sample.mt[,4] <- eta
lhs.sample.mt[,5] <- beta
lhs.sample.mt[,6] <- amp
lhs.sample.mt[,7] <- phi
 

total_run <- 50
len_each_run <- N_sample_size/total_run


 
