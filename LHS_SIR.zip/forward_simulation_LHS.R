library(deSolve)
library(readxl)

source("RSV_transmission_model_interferen_climate.R")



results <- ode(y = yinit.vector, 
               time = my_times, 
               func = RSV_transmission_model_interference_climate, 
               parms = my_parmset)

my_parmset <- my_parmset


burnN <- t_burn_in

results.burned <- results[-c(1:t_burn_in),]

pop.all <- rowSums(results.burned[,-1])

infected.cols <- results.burned[,
                                c(grep('I1', colnames(results.burned)),
                                  grep('I2', colnames(results.burned)),
                                  grep('I3', colnames(results.burned)),
                                  grep('I4', colnames(results.burned)))]

infected.cols <- results.burned[,
                                c(grep('S0', colnames(results.burned)))]


## Sum up the infected individuals at each time point
infected.all <- apply(infected.cols,1,sum)
#plot(pop.all,type="l",xlab="time (week)",ylab="population")
# plot(infected.all*parm_viral_interference_climate_prediction$reporting_fraction, type='l',xlab="time (week)",
#      ylab="prevalence of infection")
## calculate hosp no. ##

### calculate hospitalization
#proportion of first infections that are LRI (by age)
delta1=c(rep(.40,3),rep(.39,3),rep(.21,3),
         rep(.20,3),0.16,rep(.14,3),rep(0.05,N_ages-16))
#proportion of second infections that are LRI
delta2=.5*delta1
#proportion of third infections that are LRI
delta3=.7*delta2

###########################################
# Hospitalization probability
###########################################
#proportion of first infection that are hospitalized
hosp1=c(.18*rep(.40,3),0.08*rep(.39,3),
        0.07*rep(.21,3),0.06*rep(.20,3),0.06*0.16,
        0.05*rep(.14,3),0.02*rep(0.05,N_ages-16))
# = hosp prob given LRI * LRI prob given infection
#proportion of second infection that are hospitalized
hosp2=.4*hosp1
#proportion of subsequent infection that are hospitalized #(The last two probabilities come from the previous #fitting of the transmission dynamic model)
hosp3=c(rep(0,N_ages-2),0.00001,0.00004)


q <- 1
b <-  my_parmset$baseline.txn.rate/(my_parmset$dur.days1/7)
beta <- (b/100)/(sum(yinit.matrix)^(1-q))*my_parmset$contact
Amp <-  my_parmset$Amp
phi <-  my_parmset$phi
t0 <-  nrow(results.burned)

I1 <- results.burned[,grep('I1', colnames(results.burned))]
I2 <- results.burned[,grep('I2', colnames(results.burned))]
I3 <- results.burned[,grep('I3', colnames(results.burned))]
I4 <- results.burned[,grep('I4', colnames(results.burned))]
S0 <- results.burned[,grep('S0', colnames(results.burned))]
S1 <- results.burned[,grep('S1', colnames(results.burned))]
S2 <- results.burned[,grep('S2', colnames(results.burned))]
S3 <- results.burned[,grep('S3', colnames(results.burned))]


lambda1=matrix(0,nrow=t0,ncol=N_ages)
for (t in 1:t0) {lambda1[t,]<-as.vector((1+Amp*cos(2*pi*(t-phi*52.1775)/52.1775))*
                                          ((I1[t,]+rho1*I2[t,]+rho2*I3[t,]+rho2*I4[t,])
                                           %*%beta)/sum(results.burned[t,]))}



H1=matrix(0,nrow=t0,ncol=N_ages)
for (i in 1:N_ages){
  H1[,i]=hosp1[i]*S0[,i]*lambda1[,i]+
    hosp2[i]*sigma1*S1[,i]*lambda1[,i]+
    hosp3[i]*sigma2*S2[,i]*lambda1[,i]+
    hosp3[i]*sigma3*S3[,i]*lambda1[,i]}

H_predicted <- rowSums(H1)
H_predicted <- H_predicted * my_parmset$reporting_fraction

 

