library(tidyr)
library(deSolve)
library(dplyr)

setwd(dir = "/Users/ke/Desktop/test_code/Sweden_study-main/two_strain_model/")
source("two_pathogen_model.R")
source("two_pathogen_model2.R")

my_times = readRDS("my_times.rds")
yinit.vector = readRDS("yinit.vector.rds")


my_parameters1 = readRDS("parameter_set_1.rds")
my_parameters1$DurationFluImmunity= NULL
my_parameters1$dur.days.flu  = NULL
my_parameters2 = readRDS("fitted_parameters.rds") 
my_parameters = c(my_parameters1, my_parameters2)
PerCapitaBirthsYear = my_parameters$PerCapitaBirthsYear
WidthAgeClassMonth = my_parameters$WidthAgeClassMonth
yinit.matrix  = my_parameters$yinit.matrix  


############################################# 

results2 <- ode(y = yinit.vector, 
                t = my_times,  
                func = two_pathogen_model, 
                parms = my_parameters,
                atol = 1e-6, 
                rtol = 1e-6)

{N_ages = 21
  
  ### calculate hospitalization 
  #proportion of first infections that are LRI (by age)
  delta1=c(rep(.40,3),rep(.39,3),rep(.21,3),
           rep(.20,3),0.16,rep(.14,3),rep(0.05,N_ages-16))
  #proportion of second infections that are LRI
  delta2=.5*delta1
  #proportion of third infections that are LRI 
  delta3=.7*delta2 
  
  ###########################################
  # Hospitalization probability
  ###########################################
  #proportion of first infection that are hospitalized
  hosp1=c(.18*rep(.40,3),0.08*rep(.39,3),
          0.07*rep(.21,3),0.06*rep(.20,3),0.06*0.16,
          0.05*rep(.14,3),0.02*rep(0.05,N_ages-16))
  # = hosp prob given LRI * LRI prob given infection
  #proportion of second infection that are hospitalized
  hosp2=.4*hosp1
  #proportion of subsequent infection that are hospitalized #(The last two probabilities come from the previous #fitting of the transmission dynamic model) 
  hosp3=c(rep(0,N_ages-2),0.00001,0.00004)
  
  
  q <- 1 
  
  beta0 <-  my_parameters$baseline.txn.rate/(my_parameters$dur.days1/7)
  beta <- (beta0/100)/(sum(yinit.matrix)^(1-q))*my_parameters$contact
  Amp <-  my_parameters$Amp
  phi <-  my_parameters$phi
  
  t0 = nrow(results2)
  
  
  Xi1s <- results2[,grep('Xi1s', colnames(results2))] 
  Xi2s <- results2[,grep('Xi2s', colnames(results2))]
  Xi3s <- results2[,grep('Xi3s', colnames(results2))]
  Xi4s <- results2[,grep('Xi4s', colnames(results2))]
  
  Xi1r <- results2[,grep('Xi1r', colnames(results2))] 
  Xi2r <- results2[,grep('Xi2r', colnames(results2))]
  Xi3r <- results2[,grep('Xi3r', colnames(results2))]
  Xi4r <- results2[,grep('Xi4r', colnames(results2))]
  
  Xi1i <- results2[,grep('Xi1i', colnames(results2))] 
  Xi2i <- results2[,grep('Xi2i', colnames(results2))]
  Xi3i <- results2[,grep('Xi3i', colnames(results2))]
  Xi4i <- results2[,grep('Xi4i', colnames(results2))]
  
  Xss <- results2[,grep('Xss', colnames(results2))]
  Xs1s <- results2[,grep('Xs1s', colnames(results2))]
  Xs2s <- results2[,grep('Xs2s', colnames(results2))]
  Xs3s <- results2[,grep('Xs3s', colnames(results2))]
  
  
  Xsi <- results2[,grep('Xsi', colnames(results2))]
  Xs1i <- results2[,grep('Xs1i', colnames(results2))]
  Xs2i <- results2[,grep('Xs2i', colnames(results2))]
  Xs3i <- results2[,grep('Xs3i', colnames(results2))]
  
  Xsr <- results2[,grep('Xsr', colnames(results2))]
  Xs1r <- results2[,grep('Xs1r', colnames(results2))]
  Xs2r <- results2[,grep('Xs2r', colnames(results2))]
  Xs3r <- results2[,grep('Xs3r', colnames(results2))]
  
  lambda1=matrix(0,nrow=t0,ncol=N_ages)
  
  rho1 = my_parameters$rho1
  rho2 = my_parameters$rho2
  
  
  
  for (t in 1:t0) {lambda1[t,]<-as.vector((1+Amp*cos(2*pi*(t-phi*52.1775)/52.1775))*
                                            (
                                              (Xi1s[t,]+rho1*Xi2s[t,]+rho2*Xi3s[t,]+rho2*Xi4s[t,] + xi1 * (Xi1i[t,] + rho1*Xi2i[t,] + rho2*Xi3i[t,] + rho2*Xi4i[t,]) + 
                                                 Xi1r[t,]+rho1*Xi2r[t,]+rho2*Xi3r[t,]+rho2*Xi4r[t,])
                                              %*%beta)/sum(results2[t,]))}
  
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  
  sigma1 = my_parameters$sigma1
  sigma2 = my_parameters$sigma2
  sigma3 = my_parameters$sigma3
  
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*(Xss[,i] + Xsi[,i] + Xsr[,i]) *lambda1[,i]+
      hosp2[i]*sigma1*(Xs1s[,i] +  Xs1i[,i] + Xs1r[,i]) *lambda1[,i]+
      hosp3[i]*sigma2*(Xs2s[,i] + Xs2i[,i] + Xs2r[,i])*lambda1[,i]+
      hosp3[i]*sigma3*(Xs3s[,i] + Xs3i[,i] + Xs3r[,i])*lambda1[,i]}
  
  H_RSV1 <- rowSums(H1)
  H_RSV1 <- H_RSV1[1:52] * my_parameters$reporting_fraction
  
  
  
  beta0.flu <- my_parameters$baseline.txn.rate.flu/(my_parameters$dur.days.flu/7)
  beta.flu <- (beta0.flu/100)/(sum(yinit.matrix)^(1-q))*my_parameters$contact
  Amp.flu <-  my_parameters$Amp.flu
  phi.flu <-  my_parameters$phi.flu
  
  
  Xsi <- results2[,grep('Xsi', colnames(results2))] 
  Xs1i <- results2[,grep('Xs1i', colnames(results2))]
  Xs2i <- results2[,grep('Xs2i', colnames(results2))]
  Xs3i <- results2[,grep('Xs3i', colnames(results2))]
  
  Xi1i <- results2[,grep('Xi1i', colnames(results2))] 
  Xi2i <- results2[,grep('Xi2i', colnames(results2))]
  Xi3i <- results2[,grep('Xi3i', colnames(results2))]
  Xi4i <- results2[,grep('Xi4i', colnames(results2))]
  
  Xss <- results2[,grep('Xss', colnames(results2))]
  Xs1s <- results2[,grep('Xs1s', colnames(results2))]
  Xs2s <- results2[,grep('Xs2s', colnames(results2))]
  Xs3s <- results2[,grep('Xs3s', colnames(results2))]
  
  Xis <- results2[,grep('Xi1s', colnames(results2))]
  Xi1s <- results2[,grep('Xi2s', colnames(results2))]
  Xi2s <- results2[,grep('Xi3s', colnames(results2))]
  Xi3s <- results2[,grep('Xi4s', colnames(results2))]
  
  
  lambda2=matrix(0,nrow=t0,ncol=N_ages)
  
  rho1 = my_parameters$rho1
  rho2 = my_parameters$rho2
  xi1 = my_parameters$xi1
  xi2 = my_parameters$xi2
  
  for (t in 1:t0) {lambda2[t,]<-as.vector((1+Amp.flu*cos(2*pi*(t-phi.flu*52.1775)/52.1775))*
                                            (
                                              (Xsi[t,] + Xs1i[t,] + Xs2i[t,] + Xs3i[t,] + xi2 * (Xi1i[t,] + Xi2i[t,] + Xi3i[t,] + Xi4i[t,]) )
                                              %*%beta.flu)/sum(results2[t,]))}
  
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  
  sigma1 = my_parameters$sigma1
  sigma2 = my_parameters$sigma2
  sigma3 = my_parameters$sigma3
  
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*(Xss[,i] + Xis[,i] ) *lambda2[,i]+
      hosp2[i]*sigma1*(Xs1s[,i] + Xi1s[,i]) *lambda2[,i]+
      hosp3[i]*sigma2*(Xs2s[,i] + Xi2s[,i])*lambda2[,i]+
      hosp3[i]*sigma3*(Xs3s[,i] + Xi3s[,i])*lambda2[,i]}
  
  H_IFV1 <- rowSums(H1)
  H_IFV1 <- H_IFV1[1:52] * my_parameters$reporting_fraction.flu
}





##########################################################





test = results2[53,] # the first day following the pandemic
test2 = test[-1]  # get ride of the time index
test2_mat = matrix(test2, nrow = 21)
rownames(test2_mat) = rownames(yinit.matrix)
colnames(test2_mat) = colnames(yinit.matrix)
test2 <- as.vector(test2_mat)
names(test2) <- paste(rep(rownames(test2_mat), times = ncol(test2_mat)),
                      rep(colnames(test2_mat), each = nrow(test2_mat)),
                      sep = "_")

my_parameters3 = my_parameters
my_parameters3$yinit.matrix = test2_mat
my_times2 = my_times[53:468]
 

results3 <- ode(y = test2, 
                t = my_times2,  
                func = two_pathogen_model2, 
                parms = my_parameters3,
                atol = 1e-6, 
                rtol = 1e-6)

{N_ages = 21
  
  ### calculate hospitalization 
  #proportion of first infections that are LRI (by age)
  delta1=c(rep(.40,3),rep(.39,3),rep(.21,3),
           rep(.20,3),0.16,rep(.14,3),rep(0.05,N_ages-16))
  #proportion of second infections that are LRI
  delta2=.5*delta1
  #proportion of third infections that are LRI 
  delta3=.7*delta2 
  
  ###########################################
  # Hospitalization probability
  ###########################################
  #proportion of first infection that are hospitalized
  hosp1=c(.18*rep(.40,3),0.08*rep(.39,3),
          0.07*rep(.21,3),0.06*rep(.20,3),0.06*0.16,
          0.05*rep(.14,3),0.02*rep(0.05,N_ages-16))
  # = hosp prob given LRI * LRI prob given infection
  #proportion of second infection that are hospitalized
  hosp2=.4*hosp1
  #proportion of subsequent infection that are hospitalized #(The last two probabilities come from the previous #fitting of the transmission dynamic model) 
  hosp3=c(rep(0,N_ages-2),0.00001,0.00004)
  
  
  q <- 1 
  
  beta0 <-  my_parameters$baseline.txn.rate/(my_parameters$dur.days1/7)
  beta <- (beta0/100)/(sum(yinit.matrix)^(1-q))*my_parameters$contact
  Amp <-  my_parameters$Amp
  phi <-  my_parameters$phi
  
  t0 = nrow(results3)
  
  
  Xi1s <- results3[,grep('Xi1s', colnames(results3))] 
  Xi2s <- results3[,grep('Xi2s', colnames(results3))]
  Xi3s <- results3[,grep('Xi3s', colnames(results3))]
  Xi4s <- results3[,grep('Xi4s', colnames(results3))]
  
  Xi1r <- results3[,grep('Xi1r', colnames(results3))] 
  Xi2r <- results3[,grep('Xi2r', colnames(results3))]
  Xi3r <- results3[,grep('Xi3r', colnames(results3))]
  Xi4r <- results3[,grep('Xi4r', colnames(results3))]
  
  Xi1i <- results3[,grep('Xi1i', colnames(results3))] 
  Xi2i <- results3[,grep('Xi2i', colnames(results3))]
  Xi3i <- results3[,grep('Xi3i', colnames(results3))]
  Xi4i <- results3[,grep('Xi4i', colnames(results3))]
  
  Xss <- results3[,grep('Xss', colnames(results3))]
  Xs1s <- results3[,grep('Xs1s', colnames(results3))]
  Xs2s <- results3[,grep('Xs2s', colnames(results3))]
  Xs3s <- results3[,grep('Xs3s', colnames(results3))]
  
  
  Xsi <- results3[,grep('Xsi', colnames(results3))]
  Xs1i <- results3[,grep('Xs1i', colnames(results3))]
  Xs2i <- results3[,grep('Xs2i', colnames(results3))]
  Xs3i <- results3[,grep('Xs3i', colnames(results3))]
  
  Xsr <- results3[,grep('Xsr', colnames(results3))]
  Xs1r <- results3[,grep('Xs1r', colnames(results3))]
  Xs2r <- results3[,grep('Xs2r', colnames(results3))]
  Xs3r <- results3[,grep('Xs3r', colnames(results3))]
  
  lambda1=matrix(0,nrow=t0,ncol=N_ages)
  rho1 = my_parameters$rho1
  rho2 = my_parameters$rho2

  for (t in 1:t0) {lambda1[t,]<-as.vector((1+Amp*cos(2*pi*(t-phi*52.1775)/52.1775))*
                                            (
                                              (Xi1s[t,]+rho1*Xi2s[t,]+rho2*Xi3s[t,]+rho2*Xi4s[t,] + xi1 * (Xi1i[t,] + rho1*Xi2i[t,] + rho2*Xi3i[t,] + rho2*Xi4i[t,]) + 
                                                 Xi1r[t,]+rho1*Xi2r[t,]+rho2*Xi3r[t,]+rho2*Xi4r[t,])
                                              %*%beta)/sum(results3[t,]))}
  
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  
  sigma1 = my_parameters$sigma1
  sigma2 = my_parameters$sigma2
  sigma3 = my_parameters$sigma3
  
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*(Xss[,i] + Xsi[,i] + Xsr[,i]) *lambda1[,i]+
      hosp2[i]*sigma1*(Xs1s[,i] +  Xs1i[,i] + Xs1r[,i]) *lambda1[,i]+
      hosp3[i]*sigma2*(Xs2s[,i] + Xs2i[,i] + Xs2r[,i])*lambda1[,i]+
      hosp3[i]*sigma3*(Xs3s[,i] + Xs3i[,i] + Xs3r[,i])*lambda1[,i]}
  
  H_RSV2 <- rowSums(H1)
  H_RSV2 <- H_RSV2[1:312] * my_parameters$reporting_fraction
  
  
  
  beta0.flu <- my_parameters$baseline.txn.rate.flu/(my_parameters$dur.days.flu/7)
  beta.flu <- (beta0.flu/100)/(sum(yinit.matrix)^(1-q))*my_parameters$contact
  Amp.flu <-  my_parameters$Amp.flu
  phi.flu <-  my_parameters$phi.flu
  
  
  Xsi <- results3[,grep('Xsi', colnames(results3))] 
  Xs1i <- results3[,grep('Xs1i', colnames(results3))]
  Xs2i <- results3[,grep('Xs2i', colnames(results3))]
  Xs3i <- results3[,grep('Xs3i', colnames(results3))]
  
  Xi1i <- results3[,grep('Xi1i', colnames(results3))] 
  Xi2i <- results3[,grep('Xi2i', colnames(results3))]
  Xi3i <- results3[,grep('Xi3i', colnames(results3))]
  Xi4i <- results3[,grep('Xi4i', colnames(results3))]
  
  Xss <- results3[,grep('Xss', colnames(results3))]
  Xs1s <- results3[,grep('Xs1s', colnames(results3))]
  Xs2s <- results3[,grep('Xs2s', colnames(results3))]
  Xs3s <- results3[,grep('Xs3s', colnames(results3))]
  
  Xis <- results3[,grep('Xi1s', colnames(results3))]
  Xi1s <- results3[,grep('Xi2s', colnames(results3))]
  Xi2s <- results3[,grep('Xi3s', colnames(results3))]
  Xi3s <- results3[,grep('Xi4s', colnames(results3))]
  
  
  lambda2=matrix(0,nrow=t0,ncol=N_ages)
  
  rho1 = my_parameters$rho1
  rho2 = my_parameters$rho2
   
  
  for (t in 1:t0) {lambda2[t,]<-as.vector((1+Amp.flu*cos(2*pi*(t-phi.flu*52.1775)/52.1775))*
                                            (
                                              (Xsi[t,] + Xs1i[t,] + Xs2i[t,] + Xs3i[t,] + xi2 * (Xi1i[t,] + Xi2i[t,] + Xi3i[t,] + Xi4i[t,]) )
                                              %*%beta.flu)/sum(results3[t,]))}
  
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  
  sigma1 = my_parameters$sigma1
  sigma2 = my_parameters$sigma2
  sigma3 = my_parameters$sigma3
  
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*(Xss[,i] + Xis[,i] ) *lambda2[,i]+
      hosp2[i]*sigma1*(Xs1s[,i] + Xi1s[,i]) *lambda2[,i]+
      hosp3[i]*sigma2*(Xs2s[,i] + Xi2s[,i])*lambda2[,i]+
      hosp3[i]*sigma3*(Xs3s[,i] + Xi3s[,i])*lambda2[,i]}
  
  H_IFV2 <- rowSums(H1)
  H_IFV2 <- H_IFV2[1:312] * my_parameters$reporting_fraction.flu
}

H_RSV = c(H_RSV1, H_RSV2)
H_IFV = c(H_IFV1, H_IFV2)

H_RSV_base = readRDS("H_RSV_base.rds")
H_IFV_base = readRDS("H_IFV_base.rds")

data = readRDS("clean_data_RSV_FLU.rds")
par(mfrow = c(1, 2))  # Set layout to 1 row, 2 columns
plot(data$date[573:936], data$RSV[573:936], type = "l", ylim = c(0,80), ylab = "# of Hospitalizations RSV", xlab = "Date", cex.lab = 1.4,cex.axis = 1.2,cex = 1.2)
lines(data$date[573:936], H_RSV,  col = 'red', lwd = 2)
lines(data$date[573:936], H_RSV_base,  col = 'pink', lwd = 2)

legend("topleft", legend = c("Data", "Model Predictions (with interference)", "Model Predictions (without interference)"),
       col = c("black", "red", "pink"), lwd = 2, bty = "n")

plot(data$date[573:936], data$Influenza[573:936], type = "l", ylim = c(0,40),  ylab = "# of Hospitalizations influenza", xlab = "Date", cex.lab = 1.4,cex.axis = 1.2,cex = 1.2)
lines(data$date[573:936], H_IFV, col = 'blue', lwd = 2)
lines(data$date[573:936], H_IFV_base, col = 'lightblue', lwd = 2)
legend("topleft", legend = c("Data", "Model Predictions (with interference)", "Model Predictions (without interference)"),
       col = c( "black", "blue", "lightblue"), lwd = 2, bty = "n")



data_RSV.df <- data.frame(cases = data$RSV[573:936], 
                          season = rep(c(1:7), each = 52),
                          wk = rep(c(1:52), length = 364))
data_RSV_gravity <- data_RSV.df %>% 
  group_by(season) %>% 
  summarise(gravity = sum(wk * cases) / sum(cases), 
            peak = max(cases))

  
prediction_RSV.df <- data.frame(cases = H_RSV, 
                       season = rep(c(1:7), each = 52),
                       wk = rep(c(1:52), length = 364))
prediction_RSV_gravity <- prediction_RSV.df %>% 
  group_by(season) %>% 
  summarise(gravity = sum(wk * cases) / sum(cases), 
            peak = max(cases))


plot(prediction_RSV_gravity$gravity, data_RSV_gravity$gravity, xlim = c(30,40), ylim = c(30,40),
     ylab = "Center of gravity (data)", xlab = "Center of gravity (model prediction)", cex.lab = 1.4,cex.axis = 1.2,cex = 1.2, lwd = 2)
abline(a = 0, b =1)

plot(prediction_RSV_gravity$peak, data_RSV_gravity$peak, xlim = c(0,50), ylim = c(0,50),
     ylab = "RSV intensity (data)", xlab = "RSV intensity (model prediction)", cex.lab = 1.4,cex.axis = 1.2,cex = 1.2, lwd = 2)
abline(a = 0, b =1)

 

# # Number of parameters
# k <- length(fitLL$par)
# # Log-likelihood at optimum
# logLik <- fitLL$value  # since fnscale = -1, value is the *maximum* log-likelihood
# # Calculate AIC
# AIC <- 2 * k - 2 * logLik
# AIC

