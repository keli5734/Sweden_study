two_pathogen_model2 <- function(t,y,parms){
  
  # read in initial states and their names
  States<-array(y, dim=dim(parms$yinit.matrix))
  dimnames(States) <- dimnames(parms$yinit.matrix)
  
  # unify the time unit of parameter inputs
  if(parms$time.step=='month'){
    period=12
    length.step=30.44 #days
  }else if(parms$time.step=='week'){
    period=52.1775
    length.step=7 #days
  }
  
  # waning rate of maternal immunity (by time step)
  omega = 1/(parms$DurationMatImmunityDays/length.step) # wanning immunity from M --> Xss
  
  
  
  # rate of recovery of first infection
  gamma1 = 1/(parms$dur.days1/length.step) 
  # rate of recovery of second infection
  gamma2 = 1/(parms$dur.days2/length.step)
  # rate of recovery of third infection
  gamma3 = 1/(parms$dur.days3/length.step)  
  gamma4 = gamma3  
  
  gamma5 = 1/(parms$dur.days.flu/length.step) # this is for flu infection 
  
  
  # Relative risk of infection (2nd)
  sigma1=parms$sigma1 
  # Relative risk of infection (3rd)
  sigma2=parms$sigma2
  # Relative risk of infection (4th+)
  sigma3=parms$sigma3
  
  # Relative infectiousness (2nd)
  rho1=parms$rho1 
  # Relative infectiousness (3rd+)
  rho2=parms$rho2
  
  # Reduction of host susceptibility due to infection of rsv 
  theta4 = parms$theta4
  # Reduction of host susceptibility due to infection of flu
  theta3 = parms$theta3
  
  # short infection due to flu
  eta2 = parms$eta2
  # short infection due of rsv 
  eta1 = parms$eta1
  
  # reduction of infectivity of flu due to co-infection 
  xi2 = parms$xi2 
  # reduction of infectivity of rsv due to co-infection 
  xi1 = parms$xi1 
  
  
  # wanning immunity of flu 
  omega_prime = 1/(parms$DurationFluImmunity/length.step) # wanning immunity from M --> Xss
  
  #Pull out the states for the model as vectors
  M <-  States[,'M']  
  
  Xss <-  States[,'Xss'] 
  Xi1s <-  States[,'Xi1s']  
  Xs1s <-  States[,'Xs1s']
  Xi2s <-  States[,'Xi2s']
  Xs2s <-  States[,'Xs2s']
  Xi3s <-  States[,'Xi3s']
  Xs3s <-  States[,'Xs3s']
  Xi4s <-  States[,'Xi4s']
  
  Xsi <-  States[,'Xsi']  
  Xi1i <-  States[,'Xi1i']  
  Xs1i <-  States[,'Xs1i']
  Xi2i <-  States[,'Xi2i']
  Xs2i <-  States[,'Xs2i']
  Xi3i <-  States[,'Xi3i']
  Xs3i <-  States[,'Xs3i']
  Xi4i <-  States[,'Xi4i']
  
  
  Xsr <-  States[,'Xsr']  
  Xi1r <-  States[,'Xi1r']  
  Xs1r <-  States[,'Xs1r']
  Xi2r <-  States[,'Xi2r']
  Xs2r <-  States[,'Xs2r']
  Xi3r <-  States[,'Xi3r']
  Xs3r <-  States[,'Xs3r']
  Xi4r <-  States[,'Xi4r']
  
  N_ages <- length(M) # the number of age groups
  
  ## parameter related to force of infection ################
  # per capita transmission probability
  baseline.txn.rate=parms$baseline.txn.rate
  baseline.txn.rate.flu = parms$baseline.txn.rate.flu # this is flu
  # transmission probability per unit time
  b <- baseline.txn.rate/ (parms$dur.days1/length.step) 
  b.flu <- baseline.txn.rate.flu/(parms$dur.days.flu/length.step)
  q = parms$q #  
  
  contact=parms$contact # 
  # transmission probability per unit time in each age group
  beta <- (b/100)/(sum(yinit.matrix)^(1-q))*contact 
  beta.flu <- (b.flu/100)/(sum(yinit.matrix)^(1-q))*contact 
  
  
  Amp=parms$Amp # seasonal amplitude
  phi=parms$phi # seasonal phase shift
  
  #seasonality
  seasonal.txn <- (1+Amp*cos(2*pi*(t-phi*period)/period))
  
  Amp.flu = parms$Amp.flu
  phi.flu = parms$phi.flu
  season.txn.flu =  (1+Amp.flu*cos(2*pi*(t-phi.flu*period)/period))
  
  
  # seasonal transmission probability
  beta_a_i <- seasonal.txn * beta 
  beta_a_i.flu <- season.txn.flu * beta.flu
  
  infectiousN <- (Xi1s+rho1*Xi2s+rho2*Xi3s+rho2*Xi4s + xi1 * (Xi1i + rho1*Xi2i + rho2*Xi3i + rho2*Xi4i) + Xi1r+rho1*Xi2r+rho2*Xi3r+rho2*Xi4r)/sum(States)
  
  infectiousN.flu <- (Xsi + Xs1i + Xs2i + Xs3i + xi2 * (Xi1i + Xi2i + Xi3i + Xi4i) )/sum(States)
  
  
  # for frequency dependent transmission
  
  lambda <- infectiousN %*% beta_a_i # force of transmission
  lambda <- as.vector(lambda) # vectorize force of transmission
  
  lambda.flu <- infectiousN.flu %*% beta_a_i.flu
  lambda.flu <- as.vector(lambda.flu) 
  
  # create a matrix to record the changing variables
  dy <- matrix(NA, nrow=N_ages, ncol=ncol(States))
  colnames(dy) <- colnames(States)
  
  period.birth.rate <- 
    log(parms$PerCapitaBirthsYear[t,]+1)/period
  # get period birth rate from annual birth rate
  # see the following page for birth rate calculation
  
  #um is death rate
  mu=parms$mu
  
  # aging rate (by time step)
  AGE = 1/parms$WidthAgeClassMonth
  if(parms$time.step=='week'){
    AGE = 1/(WidthAgeClassMonth*4.345)} 
  
  #mu represents aging to the next class
  Aging.Prop <- c(0,AGE[1:(N_ages-1)])
  
  
  dy[,'M'] <- period.birth.rate*sum(States) - 
    omega * M - AGE * M - mu * M[1:(N_ages)] +
    Aging.Prop*c(0,M[1:(N_ages-1)]) 
  
  dy[,'Xss'] <- omega * M -
    (lambda + lambda.flu)*Xss - AGE * Xss - mu * Xss[1:(N_ages)] +
    Aging.Prop*c(0,Xss[1:(N_ages-1)])  + omega_prime * Xsr
  
  dy[,'Xi1s'] <-   lambda*Xss - 
    (gamma1 + theta4 * lambda.flu)*Xi1s  - AGE * Xi1s - mu * Xi1s[1:(N_ages)] +
    Aging.Prop*c(0,Xi1s[1:(N_ages-1)]) + omega_prime * Xi1r
  
  dy[,'Xs1s'] <- gamma1*Xi1s - 
    sigma1*lambda*Xs1s - 
    (lambda.flu)*Xs1s - AGE * Xs1s - mu * Xs1s[1:(N_ages)] +
    Aging.Prop*c(0,Xs1s[1:(N_ages-1)])  + omega_prime * Xs1r
  
  dy[,'Xi2s'] <- sigma1*lambda*Xs1s - 
    gamma2*Xi2s -
    (theta4 * lambda.flu)*Xi2s - AGE * Xi2s - mu * Xi2s[1:(N_ages)] +
    Aging.Prop*c(0,Xi2s[1:(N_ages-1)]) + omega_prime * Xi2r
  
  dy[,'Xs2s'] <- gamma2*Xi2s - 
    sigma2*lambda*Xs2s -
    (lambda.flu)*Xs2s - AGE * Xs2s - mu * Xs2s[1:(N_ages)] +
    Aging.Prop*c(0,Xs2s[1:(N_ages-1)]) + omega_prime * Xs2r
  
  dy[,'Xi3s'] <- sigma2*lambda*Xs2s -
    (gamma3 +theta4*lambda.flu)*Xi3s - AGE * Xi3s -
    mu * Xi3s[1:(N_ages)] +
    Aging.Prop*c(0,Xi3s[1:(N_ages-1)]) + omega_prime * Xi3r
  
  dy[,'Xs3s'] <- gamma3*Xi3s +  
    gamma4*Xi4s -
    sigma3*lambda*Xs3s -
    (lambda.flu)*Xs3s - AGE * Xs3s - mu * Xs3s[1:(N_ages)] +
    Aging.Prop*c(0,Xs3s[1:(N_ages-1)])  + omega_prime * Xs3r
  
  dy[,'Xi4s'] <- sigma3*lambda*Xs3s - 
    gamma4*Xi4s - 
    (theta4 * lambda.flu)*Xi4s - AGE * Xi4s -
    mu * Xi4s[1:(N_ages)] +
    Aging.Prop*c(0,Xi4s[1:(N_ages-1)])  + omega_prime * Xi4r
  
  
  dy[,'Xsi'] <- lambda.flu*Xss - 
    (theta3 * lambda + gamma5)*Xsi - AGE * Xsi -
    mu * Xsi[1:(N_ages)] +
    Aging.Prop*c(0,Xsi[1:(N_ages-1)])
  
  dy[,'Xi1i'] <- theta4*lambda.flu*Xi1s +
    theta3*lambda*Xsi - 
    (eta1 * gamma1 + eta2 * gamma5) * Xi1i - AGE * Xi1i -
    mu * Xi1i[1:(N_ages)] +
    Aging.Prop*c(0,Xi1i[1:(N_ages-1)])
  
  dy[,'Xs1i'] <- lambda.flu* Xs1s + 
    eta1*gamma1*Xi1i - 
    (gamma5 + theta3 * sigma1*lambda) * Xs1i - AGE * Xs1i -
    mu * Xs1i[1:(N_ages)] +
    Aging.Prop*c(0,Xs1i[1:(N_ages-1)])
  
  dy[,'Xi2i'] <- theta3 * sigma1*lambda* Xs1i + 
    theta4 * lambda.flu*Xi2s - 
    (eta1*gamma2 + eta2*gamma5) * Xi2i - AGE * Xi2i -
    mu * Xi2i[1:(N_ages)] +
    Aging.Prop*c(0,Xi2i[1:(N_ages-1)])
  
  dy[,'Xs2i'] <- lambda.flu*Xs2s + 
    eta1 * gamma2 * Xi2i - 
    (theta3*sigma2*lambda + gamma5) * Xs2i -AGE * Xs2i -
    mu * Xs2i[1:(N_ages)] +
    Aging.Prop*c(0,Xs2i[1:(N_ages-1)])
  
  
  dy[,'Xi3i'] <- theta4*lambda.flu*Xi3s + 
    theta3*sigma2*lambda*Xs2i - 
    (eta1*gamma3 + eta2*gamma5) * Xi3i - 
    AGE * Xi3i -
    mu * Xi3i[1:(N_ages)] +
    Aging.Prop*c(0,Xi3i[1:(N_ages-1)])
  
  dy[,'Xs3i'] <- lambda.flu*Xs3s + 
    eta1 * gamma3*Xi3i +
    eta1 * gamma4*Xi4i -
    (gamma5 + theta3*sigma3*lambda) * Xs3i - 
    AGE * Xs3i -
    mu * Xs3i[1:(N_ages)] +
    Aging.Prop*c(0,Xs3i[1:(N_ages-1)])
  
  dy[,'Xi4i'] <- theta4 *lambda.flu*Xi4s + 
    theta3 * lambda * sigma3 * Xs3i -
    (eta1*gamma4 + eta2*gamma5) * Xi4i -
    AGE * Xi4i -
    mu * Xi4i[1:(N_ages)] +
    Aging.Prop*c(0,Xi4i[1:(N_ages-1)])
  
  dy[,'Xsr'] <- gamma5*Xsi -
    (lambda) * Xsr - 
    AGE * Xsr -
    mu * Xsr[1:(N_ages)] +
    Aging.Prop*c(0,Xsr[1:(N_ages-1)]) -  omega_prime * Xsr
  
  dy[,'Xi1r'] <- lambda*Xsr + 
    eta2 *gamma5*Xi1i - 
    (gamma1) * Xi1r - 
    AGE * Xi1r -
    mu * Xi1r[1:(N_ages)] +
    Aging.Prop*c(0,Xi1r[1:(N_ages-1)]) -  omega_prime * Xi1r
  
  dy[,'Xs1r'] <- gamma1 * Xi1r + 
    gamma5 * Xs1i - 
    (sigma1*lambda) * Xs1r -
    AGE * Xs1r -
    mu * Xs1r[1:(N_ages)] +
    Aging.Prop*c(0,Xs1r[1:(N_ages-1)]) -  omega_prime * Xs1r
  
  dy[,'Xi2r'] <- eta2*gamma5 * Xi2i + 
    sigma1*lambda*Xs1r - 
    (gamma2) * Xi2r -
    AGE * Xi2r -
    mu * Xi2r[1:(N_ages)] +
    Aging.Prop*c(0,Xi2r[1:(N_ages-1)]) -  omega_prime * Xi2r
  
  dy[,'Xs2r'] <- gamma5 * Xs2i + 
    gamma2 * Xi2r - 
    (sigma2*lambda) * Xs2r -
    AGE * Xs2r -
    mu * Xs2r[1:(N_ages)] +
    Aging.Prop*c(0,Xs2r[1:(N_ages-1)])-  omega_prime * Xs2r
  
  dy[,'Xi3r'] <- eta2* gamma5 * Xi3i + 
    sigma2*lambda*Xs2r - 
    (gamma3) * Xi3r - 
    AGE * Xi3r -
    mu * Xi3r[1:(N_ages)] +
    Aging.Prop*c(0,Xi3r[1:(N_ages-1)]) -  omega_prime * Xi3r
  
  dy[,'Xs3r'] <- gamma5 * Xs3i + 
    gamma3* Xi3r +gamma4 * Xi4r - 
    (sigma3*lambda) * Xs3r -
    AGE * Xs3r -
    mu * Xs3r[1:(N_ages)] +
    Aging.Prop*c(0,Xs3r[1:(N_ages-1)]) -  omega_prime * Xs3r
  
  dy[,'Xi4r'] <- eta2 * gamma5 * Xi4i + 
    sigma3*lambda*Xs3r - 
    (gamma4) * Xi4r -
    AGE * Xi4r -
    mu * Xi4r[1:(N_ages)] +
    Aging.Prop*c(0,Xi4r[1:(N_ages-1)]) -  omega_prime * Xi4r
  
  
  
  derivs <- as.vector(dy)
  
  res <- list(derivs)
  
  return(res)
}






