library(tidyr)
library(deSolve)
library(dplyr)

#setwd(dir = "Sweden_two_strain_model/")

clean_data <-  readRDS("clean_data_RSV_FLU.rds")

data_fit_null_model <- clean_data %>% 
  select(RSV, Influenza)


set.seed(1250)


source("fit_hosp_data_fn.R")
fitLL <- optim(par=c(-1.6, .1, 1.3, 0, 0, 5.6, -0.69, 0, 0, log(10)), 
               fn = fit_hosp_data_fn, # the distance function to optimise
               dat = data_fit_null_model, # the dataset we fit to
               control = list(fnscale= -1)  # negative log likelihood # here we minimize the negative log likelihood
) 

parms <- c(Amp.flu=exp(fitLL$par[1]),
           phi.flu=(2*pi*(exp(fitLL$par[2]))) / (1+exp(fitLL$par[2])),
           baseline.txn.rate.flu = exp(fitLL$par[3]),
           theta1 = (fitLL$par[4]),
           theta2 = (fitLL$par[5]),
           DurationFluImmunity = exp(fitLL$par[6]),
           reporting_fraction.flu = exp(fitLL$par[7]),
           theta3 = (fitLL$par[8]),
           theta4 = (fitLL$par[9]),
           dur.days.flu = exp(fitLL$par[10]))
           

 