

library(tidyverse)
library(deSolve)
 
setwd("/Users/ke/Desktop/OneDrive - Yale University/Postdoc projects/virus-virus interfernce/Sweden/sweden/")
source("two_strain_model/parameter_setting_viral_interference.R")
source("two_strain_model/two_pathogen_model.R")
data <- readRDS("two_strain_model/clean_data_RSV_FLU.rds")

   
results <- ode(y = yinit.vector, 
               t = my_times,
               func = two_pathogen_model,
               parms = model_parm)
my_parameters = model_parm

results.burned <- results[-c(1:burnN),]


#results.burned.all <- apply(results.burned, 1, sum)

pop.all <- rowSums(results.burned[,-1])

{N_ages = 21
  
  ### calculate hospitalization 
  #proportion of first infections that are LRI (by age)
  delta1=c(rep(.40,3),rep(.39,3),rep(.21,3),
           rep(.20,3),0.16,rep(.14,3),rep(0.05,N_ages-16))
  #proportion of second infections that are LRI
  delta2=.5*delta1
  #proportion of third infections that are LRI 
  delta3=.7*delta2 
  
  ###########################################
  # Hospitalization probability
  ###########################################
  #proportion of first infection that are hospitalized
  hosp1=c(.18*rep(.40,3),0.08*rep(.39,3),
          0.07*rep(.21,3),0.06*rep(.20,3),0.06*0.16,
          0.05*rep(.14,3),0.02*rep(0.05,N_ages-16))
  # = hosp prob given LRI * LRI prob given infection
  #proportion of second infection that are hospitalized
  hosp2=.4*hosp1
  #proportion of subsequent infection that are hospitalized #(The last two probabilities come from the previous #fitting of the transmission dynamic model) 
  hosp3=c(rep(0,N_ages-2),0.00001,0.00004)
  
  
  q <- 1 
  
  beta0 <-  my_parameters$baseline.txn.rate/(my_parameters$dur.days1/7)
  beta <- (beta0/100)/(sum(yinit.matrix)^(1-q))*my_parameters$contact
  Amp <-  my_parameters$Amp
  phi <-  my_parameters$phi
  
  t0 = nrow(results.burned)
  
  
  Xi1s <- results.burned[,grep('Xi1s', colnames(results.burned))] 
  Xi2s <- results.burned[,grep('Xi2s', colnames(results.burned))]
  Xi3s <- results.burned[,grep('Xi3s', colnames(results.burned))]
  Xi4s <- results.burned[,grep('Xi4s', colnames(results.burned))]
  
  Xi1r <- results.burned[,grep('Xi1r', colnames(results.burned))] 
  Xi2r <- results.burned[,grep('Xi2r', colnames(results.burned))]
  Xi3r <- results.burned[,grep('Xi3r', colnames(results.burned))]
  Xi4r <- results.burned[,grep('Xi4r', colnames(results.burned))]
  
  Xi1i <- results.burned[,grep('Xi1i', colnames(results.burned))] 
  Xi2i <- results.burned[,grep('Xi2i', colnames(results.burned))]
  Xi3i <- results.burned[,grep('Xi3i', colnames(results.burned))]
  Xi4i <- results.burned[,grep('Xi4i', colnames(results.burned))]
  
  Xss <- results.burned[,grep('Xss', colnames(results.burned))]
  Xs1s <- results.burned[,grep('Xs1s', colnames(results.burned))]
  Xs2s <- results.burned[,grep('Xs2s', colnames(results.burned))]
  Xs3s <- results.burned[,grep('Xs3s', colnames(results.burned))]
  
  
  Xsi <- results.burned[,grep('Xsi', colnames(results.burned))]
  Xs1i <- results.burned[,grep('Xs1i', colnames(results.burned))]
  Xs2i <- results.burned[,grep('Xs2i', colnames(results.burned))]
  Xs3i <- results.burned[,grep('Xs3i', colnames(results.burned))]
  
  Xsr <- results.burned[,grep('Xsr', colnames(results.burned))]
  Xs1r <- results.burned[,grep('Xs1r', colnames(results.burned))]
  Xs2r <- results.burned[,grep('Xs2r', colnames(results.burned))]
  Xs3r <- results.burned[,grep('Xs3r', colnames(results.burned))]
  
  lambda1=matrix(0,nrow=t0,ncol=N_ages)
  rho1 = my_parameters$rho1
  rho2 = my_parameters$rho2
  xi1 = my_parameters$xi1
  xi2 = my_parameters$xi2
  for (t in 1:t0) {lambda1[t,]<-as.vector((1+Amp*cos(2*pi*(t-phi*52.1775)/52.1775))*
                                            (
                                              (Xi1s[t,]+rho1*Xi2s[t,]+rho2*Xi3s[t,]+rho2*Xi4s[t,] + xi1 * (Xi1i[t,] + rho1*Xi2i[t,] + rho2*Xi3i[t,] + rho2*Xi4i[t,]) + 
                                                 Xi1r[t,]+rho1*Xi2r[t,]+rho2*Xi3r[t,]+rho2*Xi4r[t,])
                                              %*%beta)/sum(results.burned[t,]))}
  
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  
  sigma1 = my_parameters$sigma1
  sigma2 = my_parameters$sigma2
  sigma3 = my_parameters$sigma3
  
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*(Xss[,i] + Xsi[,i] + Xsr[,i]) *lambda1[,i]+
      hosp2[i]*sigma1*(Xs1s[,i] +  Xs1i[,i] + Xs1r[,i]) *lambda1[,i]+
      hosp3[i]*sigma2*(Xs2s[,i] + Xs2i[,i] + Xs2r[,i])*lambda1[,i]+
      hosp3[i]*sigma3*(Xs3s[,i] + Xs3i[,i] + Xs3r[,i])*lambda1[,i]}
  
  H_RSV <- rowSums(H1)
  
  
  
  beta0.flu <- my_parameters$baseline.txn.rate.flu/(my_parameters$dur.days.flu/7)
  beta.flu <- (beta0.flu/100)/(sum(yinit.matrix)^(1-q))*my_parameters$contact
  Amp.flu <-  my_parameters$Amp.flu
  phi.flu <-  my_parameters$phi.flu
  
  
  Xsi <- results.burned[,grep('Xsi', colnames(results.burned))] 
  Xs1i <- results.burned[,grep('Xs1i', colnames(results.burned))]
  Xs2i <- results.burned[,grep('Xs2i', colnames(results.burned))]
  Xs3i <- results.burned[,grep('Xs3i', colnames(results.burned))]
  
  Xi1i <- results.burned[,grep('Xi1i', colnames(results.burned))] 
  Xi2i <- results.burned[,grep('Xi2i', colnames(results.burned))]
  Xi3i <- results.burned[,grep('Xi3i', colnames(results.burned))]
  Xi4i <- results.burned[,grep('Xi4i', colnames(results.burned))]
  
  Xss <- results.burned[,grep('Xss', colnames(results.burned))]
  Xs1s <- results.burned[,grep('Xs1s', colnames(results.burned))]
  Xs2s <- results.burned[,grep('Xs2s', colnames(results.burned))]
  Xs3s <- results.burned[,grep('Xs3s', colnames(results.burned))]
  
  Xis <- results.burned[,grep('Xi1s', colnames(results.burned))]
  Xi1s <- results.burned[,grep('Xi2s', colnames(results.burned))]
  Xi2s <- results.burned[,grep('Xi3s', colnames(results.burned))]
  Xi3s <- results.burned[,grep('Xi4s', colnames(results.burned))]
  
  
  lambda2=matrix(0,nrow=t0,ncol=N_ages)
  
  rho1 = my_parameters$rho1
  rho2 = my_parameters$rho2
  xi1 = my_parameters$xi1
  xi2 = my_parameters$xi2
  
  for (t in 1:t0) {lambda2[t,]<-as.vector((1+Amp.flu*cos(2*pi*(t-phi.flu*52.1775)/52.1775))*
                                            (
                                              (Xsi[t,] + Xs1i[t,] + Xs2i[t,] + Xs3i[t,] + xi2 * (Xi1i[t,] + Xi2i[t,] + Xi3i[t,] + Xi4i[t,]) )
                                              %*%beta.flu)/sum(results.burned[t,]))}
  
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  
  sigma1 = my_parameters$sigma1
  sigma2 = my_parameters$sigma2
  sigma3 = my_parameters$sigma3
  
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*(Xss[,i] + Xis[,i] ) *lambda2[,i]+
      hosp2[i]*sigma1*(Xs1s[,i] + Xi1s[,i]) *lambda2[,i]+
      hosp3[i]*sigma2*(Xs2s[,i] + Xi2s[,i])*lambda2[,i]+
      hosp3[i]*sigma3*(Xs3s[,i] + Xi3s[,i])*lambda2[,i]}
  
  H_IFV <- rowSums(H1)
}

plot(data$date, H_RSV, type = "l")
lines(data$date, H_IFV, col = "red")




######### post ########
test = results.burned[1,]
test2 = test[-1]  
test2_mat = matrix(test2, nrow = 21)
rownames(test2_mat) = agenames
colnames(test2_mat) = StateNames
test2_mat[,c('Xsi')] = c(rep(1,6), rep(1,N_ages-6))

test2 <- as.vector(test2_mat)
names(test2) <- paste(rep(rownames(test2_mat), times = ncol(test2_mat)),
                      rep(colnames(test2_mat), each = nrow(test2_mat)),
                      sep = "_")


parm_RSV   <- list(PerCapitaBirthsYear=PerCapitaBirthsYear,#[-c(1:(burnN+572)), ],
                   WidthAgeClassMonth = WidthAgeClassMonth,
                   DurationMatImmunityDays = DurationMatImmunityDays,
                   mu = migration_rates_gp,
                   rho1=rho1,
                   rho2=rho2,
                   dur.days1=dur.days1,
                   dur.days2=dur.days2,
                   dur.days3=dur.days3,
                   yinit.matrix=test2_mat,
                   baseline.txn.rate = calibrated_model_parameters$baseline.txn.rate,
                   Amp = calibrated_model_parameters$Amp,
                   phi = calibrated_model_parameters$phi,
                   reporting_fraction = calibrated_model_parameters$reporting_fraction,
                   q=q,
                   contact=contact_mat,
                   sigma1=sigma1,
                   sigma2=sigma2,
                   sigma3= sigma3,
                   time.step = 'week')



parm_interaction <- list(theta1 = .5,
                         theta2 = 1, 
                         eta1 = 1,
                         eta2 = 1,
                         xi1 = 1,
                         xi2 = 1)

parm_IFV <- list(dur.days.flu = 10,
                 DurationFluImmunity = 280,
                 Amp.flu = 0.6,
                 phi.flu = 3.2,
                 baseline.txn.rate.flu = 1.1)

model_parm <- c(parm_RSV, parm_IFV, parm_interaction)

 


results2 <- ode(y = test2, 
               t = my_times[-c(1:(burnN))],
               func = two_pathogen_model,
               parms = model_parm)

my_parameters = model_parm

{N_ages = 21
  
  ### calculate hospitalization 
  #proportion of first infections that are LRI (by age)
  delta1=c(rep(.40,3),rep(.39,3),rep(.21,3),
           rep(.20,3),0.16,rep(.14,3),rep(0.05,N_ages-16))
  #proportion of second infections that are LRI
  delta2=.5*delta1
  #proportion of third infections that are LRI 
  delta3=.7*delta2 
  
  ###########################################
  # Hospitalization probability
  ###########################################
  #proportion of first infection that are hospitalized
  hosp1=c(.18*rep(.40,3),0.08*rep(.39,3),
          0.07*rep(.21,3),0.06*rep(.20,3),0.06*0.16,
          0.05*rep(.14,3),0.02*rep(0.05,N_ages-16))
  # = hosp prob given LRI * LRI prob given infection
  #proportion of second infection that are hospitalized
  hosp2=.4*hosp1
  #proportion of subsequent infection that are hospitalized #(The last two probabilities come from the previous #fitting of the transmission dynamic model) 
  hosp3=c(rep(0,N_ages-2),0.00001,0.00004)
  
  
  q <- 1 
  
  beta0 <-  my_parameters$baseline.txn.rate/(my_parameters$dur.days1/7)
  beta <- (beta0/100)/(sum(yinit.matrix)^(1-q))*my_parameters$contact
  Amp <-  my_parameters$Amp
  phi <-  my_parameters$phi
  
  t0 = nrow(results2)
  
  
  Xi1s <- results2[,grep('Xi1s', colnames(results2))] 
  Xi2s <- results2[,grep('Xi2s', colnames(results2))]
  Xi3s <- results2[,grep('Xi3s', colnames(results2))]
  Xi4s <- results2[,grep('Xi4s', colnames(results2))]
  
  Xi1r <- results2[,grep('Xi1r', colnames(results2))] 
  Xi2r <- results2[,grep('Xi2r', colnames(results2))]
  Xi3r <- results2[,grep('Xi3r', colnames(results2))]
  Xi4r <- results2[,grep('Xi4r', colnames(results2))]
  
  Xi1i <- results2[,grep('Xi1i', colnames(results2))] 
  Xi2i <- results2[,grep('Xi2i', colnames(results2))]
  Xi3i <- results2[,grep('Xi3i', colnames(results2))]
  Xi4i <- results2[,grep('Xi4i', colnames(results2))]
  
  Xss <- results2[,grep('Xss', colnames(results2))]
  Xs1s <- results2[,grep('Xs1s', colnames(results2))]
  Xs2s <- results2[,grep('Xs2s', colnames(results2))]
  Xs3s <- results2[,grep('Xs3s', colnames(results2))]
  
  
  Xsi <- results2[,grep('Xsi', colnames(results2))]
  Xs1i <- results2[,grep('Xs1i', colnames(results2))]
  Xs2i <- results2[,grep('Xs2i', colnames(results2))]
  Xs3i <- results2[,grep('Xs3i', colnames(results2))]
  
  Xsr <- results2[,grep('Xsr', colnames(results2))]
  Xs1r <- results2[,grep('Xs1r', colnames(results2))]
  Xs2r <- results2[,grep('Xs2r', colnames(results2))]
  Xs3r <- results2[,grep('Xs3r', colnames(results2))]
  
  lambda1=matrix(0,nrow=t0,ncol=N_ages)
  rho1 = my_parameters$rho1
  rho2 = my_parameters$rho2
  xi1 = my_parameters$xi1
  xi2 = my_parameters$xi2
  for (t in 1:t0) {lambda1[t,]<-as.vector((1+Amp*cos(2*pi*(t-phi*52.1775)/52.1775))*
                                            (
                                              (Xi1s[t,]+rho1*Xi2s[t,]+rho2*Xi3s[t,]+rho2*Xi4s[t,] + xi1 * (Xi1i[t,] + rho1*Xi2i[t,] + rho2*Xi3i[t,] + rho2*Xi4i[t,]) + 
                                                 Xi1r[t,]+rho1*Xi2r[t,]+rho2*Xi3r[t,]+rho2*Xi4r[t,])
                                              %*%beta)/sum(results2[t,]))}
  
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  
  sigma1 = my_parameters$sigma1
  sigma2 = my_parameters$sigma2
  sigma3 = my_parameters$sigma3
  
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*(Xss[,i] + Xsi[,i] + Xsr[,i]) *lambda1[,i]+
      hosp2[i]*sigma1*(Xs1s[,i] +  Xs1i[,i] + Xs1r[,i]) *lambda1[,i]+
      hosp3[i]*sigma2*(Xs2s[,i] + Xs2i[,i] + Xs2r[,i])*lambda1[,i]+
      hosp3[i]*sigma3*(Xs3s[,i] + Xs3i[,i] + Xs3r[,i])*lambda1[,i]}
  
  H_RSV <- rowSums(H1)
  
  
  
  
  
  
  
  
  beta0.flu <- my_parameters$baseline.txn.rate.flu/(my_parameters$dur.days.flu/7)
  beta.flu <- (beta0.flu/100)/(sum(yinit.matrix)^(1-q))*my_parameters$contact
  Amp.flu <-  my_parameters$Amp.flu
  phi.flu <-  my_parameters$phi.flu
  
  
  Xsi <- results2[,grep('Xsi', colnames(results2))] 
  Xs1i <- results2[,grep('Xs1i', colnames(results2))]
  Xs2i <- results2[,grep('Xs2i', colnames(results2))]
  Xs3i <- results2[,grep('Xs3i', colnames(results2))]
  
  Xi1i <- results2[,grep('Xi1i', colnames(results2))] 
  Xi2i <- results2[,grep('Xi2i', colnames(results2))]
  Xi3i <- results2[,grep('Xi3i', colnames(results2))]
  Xi4i <- results2[,grep('Xi4i', colnames(results2))]
  
  Xss <- results2[,grep('Xss', colnames(results2))]
  Xs1s <- results2[,grep('Xs1s', colnames(results2))]
  Xs2s <- results2[,grep('Xs2s', colnames(results2))]
  Xs3s <- results2[,grep('Xs3s', colnames(results2))]
  
  Xis <- results2[,grep('Xi1s', colnames(results2))]
  Xi1s <- results2[,grep('Xi2s', colnames(results2))]
  Xi2s <- results2[,grep('Xi3s', colnames(results2))]
  Xi3s <- results2[,grep('Xi4s', colnames(results2))]
  
  
  lambda2=matrix(0,nrow=t0,ncol=N_ages)
  
  rho1 = my_parameters$rho1
  rho2 = my_parameters$rho2
  xi1 = my_parameters$xi1
  xi2 = my_parameters$xi2
  
  for (t in 1:t0) {lambda2[t,]<-as.vector((1+Amp.flu*cos(2*pi*(t-phi.flu*52.1775)/52.1775))*
                                            (
                                              (Xsi[t,] + Xs1i[t,] + Xs2i[t,] + Xs3i[t,] + xi2 * (Xi1i[t,] + Xi2i[t,] + Xi3i[t,] + Xi4i[t,]) )
                                              %*%beta.flu)/sum(results2[t,]))}
  
  
  
  
  H1=matrix(0,nrow=t0,ncol=N_ages) 
  
  sigma1 = my_parameters$sigma1
  sigma2 = my_parameters$sigma2
  sigma3 = my_parameters$sigma3
  
  for (i in 1:N_ages){
    H1[,i]=hosp1[i]*(Xss[,i] + Xis[,i] ) *lambda2[,i]+
      hosp2[i]*sigma1*(Xs1s[,i] + Xi1s[,i]) *lambda2[,i]+
      hosp3[i]*sigma2*(Xs2s[,i] + Xi2s[,i])*lambda2[,i]+
      hosp3[i]*sigma3*(Xs3s[,i] + Xi3s[,i])*lambda2[,i]}
  
  H_IFV <- rowSums(H1)
}


plot(data$date, H_RSV, type = "l")
lines(data$date, H_IFV, col = "red")
