library(tidyr)
library(deSolve)
library(dplyr)
 

clean_data <-  readRDS("clean_data_RSV_FLU.rds")

# clean_data %>% 
#   ggplot() + 
#   geom_line(aes(x = epi_week_cdc, y= RSV, group = season)) + 
#   facet_wrap(~season)

# calibrate model with the first 10 years from the 1998/1999 season to 2008/2009 season 

data_fit_null_model <- clean_data %>% 
  filter(date <= "2009-07-01") %>% 
  select(RSV, season, epi_week_cdc)


set.seed(1250)


source("fit_hosp_data_fn.R")
fitLL <- optim(par=c(-1.6, .1, 2.197225, -0.22, -1.6, -1.6), 
               fn = fit_hosp_data_fn, # the distance function to optimise
               dat = data_fit_null_model, # the dataset we fit to
               # ("dat" argument is passed to the function specified in fn)
               control = list(fnscale= -1)  # negative log likelihood # here we minimize the negative log likelihood
) 




parms <- c(parm_for_fit,
           Amp=exp(fitLL$par[1]),
           phi=(2*pi*(exp(fitLL$par[2]))) / (1+exp(fitLL$par[2])),
           baseline.txn.rate = exp(fitLL$par[3]),
           reporting_fraction = exp(fitLL$par[4]))


saveRDS(parms, "calibrated_parms_partial_dataset.rds")